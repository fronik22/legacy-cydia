#import <Foundation/Foundation.h>

@class YTVideoItem;

/**
 * Обращения к InnerTube — внутреннему API, которым пользуется сам YouTube.
 *
 * Порт запросов из `Config.cs`. Открытого API здесь нет и быть не может:
 * Data API v3 не отдаёт ни ленту «Главной», ни поток видео, ни комментарии
 * в том виде, в каком они нужны клиенту, а квоты делают его непригодным
 * для приложения. Поэтому запросы те же, что шлёт официальный клиент.
 *
 * **Клиент представляется по-разному в зависимости от того, что просит,**
 * и это не прихоть, а перенесённые находки UWP-версии:
 *
 *   TVHTML5  — всё, что требует входа: «Главная», подписки, история,
 *              уведомления, а также `/player`. Токен OAuth выдан именно
 *              этому клиенту, и другие с ним отвечают 400;
 *   WEB      — поиск и страница ролика, то есть всё, что работает
 *              и без входа;
 *   ANDROID  — запасной путь для `/player`, где нужны нешифрованные адреса
 *              потоков.
 *
 * Главное правило, выведенное в UWP-версии и записанное там прямо
 * в комментарии: **клиент в теле запроса обязан совпадать с клиентом
 * в заголовках.** Несовпадение — это и есть причина, по которой `/player`
 * отвечает «the page needs to be reloaded», а reel-запросы — 400.
 */
@interface YTApi : NSObject

#pragma mark Лента

/**
 * Лента «Главной». `continuation` — токен следующей страницы либо nil
 * для первой.
 *
 * Возвращает словарь с ключами `items` (массив YTVideoItem) и
 * `continuation` (строка или nil).
 */
+ (NSDictionary *)homeFeed:(NSString *)continuation;

/**
 * «Таблетки» категорий над лентой: «Все», «Музыка», «Игры»…
 *
 * Список свой, а не с сервера, — так в оригинале, и там об этом сказано
 * прямо: «Home chips are fixed locally. Do not request categories/chips
 * from Innertube». Словари с ключами `title` и `query`; у первой таблетки
 * запроса нет — она и есть лента рекомендаций.
 */
+ (NSArray *)homeCategories;

/** Эфир объявлен, но ещё не начался: потоков нет ни у одного клиента. */
+ (BOOL)isUpcomingBroadcast:(NSDictionary *)json;

/** Вкладка «Сейчас в эфире»: `FEtopics_live`, отвечает полками. */
+ (NSDictionary *)liveFeed:(NSString *)continuation;

/**
 * Лента «Главной». `params` сохранён для совместимости вызова и в обычном
 * ходе не нужен: выбранная таблетка выполняет поиск, а не листает ленту.
 */
+ (NSDictionary *)homeFeedWithParams:(NSString *)params continuation:(NSString *)continuation;

/** Поиск. */
/**
 * Разновидность искомого — порт `GetSearchParams` из `Search.xaml.cs`.
 *
 * `YTSearchAll` у оригинала соответствует «видео»: без пометки сервер
 * подмешивает в выдачу что попало. Отдельного слова для Shorts там нет
 * намеренно — «Using no type token lets the search response include
 * the Shorts shelf», и уже из общей выдачи отбираются вертикальные.
 */
typedef enum {
    YTSearchVideos = 0,
    YTSearchShorts,
    YTSearchChannels,
    YTSearchPlaylists
} YTSearchKind;

+ (NSDictionary *)search:(NSString *)query
            continuation:(NSString *)continuation
                    kind:(YTSearchKind)kind;

+ (NSDictionary *)search:(NSString *)query continuation:(NSString *)continuation;

/** Подсказки поиска — отдельная служба, не InnerTube. */
+ (NSArray *)searchSuggestions:(NSString *)query;

#pragma mark Ролик

/**
 * Страница ролика: описание, автор, счётчики, похожие, токен комментариев.
 * Ключи: `title`, `channelTitle`, `channelId`, `channelThumbnail`,
 * `subscribers`, `views`, `published`, `likes`, `description`,
 * `related` (массив YTVideoItem), `commentsToken`.
 */
+ (NSDictionary *)videoDetails:(NSString *)videoId;

/**
 * То же, но с подборкой: к ключам добавляются `queue` (массив YTVideoItem),
 * `queueTitle` и `queueIndex`.
 *
 * Без идентификатора подборки очереди в ответе не будет — сервер не знает,
 * из какого списка открыт ролик.
 */
+ (NSDictionary *)videoDetails:(NSString *)videoId playlist:(NSString *)playlistId;

/**
 * Комментарии по токену. Ключи: `items`, `continuation`, `createParams`.
 *
 * `createParams` — метка, которой сервер разрешает писать в этот ролик;
 * её отсутствие означает, что поле ввода показывать не надо.
 */
/**
 * Страница чата трансляции по метке продолжения.
 *
 * Возвращает `items` — записи `{author, text, avatar, id}`, — метку
 * следующей страницы `token` и задержку до неё `wait` в секундах
 * (её называет сам сервер, обычно десять).
 *
 * Первую метку берёт `videoDetails:` и кладёт под ключом `liveChatToken`;
 * у записи без чата её нет вовсе.
 */
+ (NSDictionary *)liveChat:(NSString *)token;

/**
 * Метки фильтров чата: «интересные сообщения» и «все сообщения», в этом
 * порядке. Каждая запись — `{token, serverTitle}`.
 *
 * Берутся со страницы `/live_chat`, а не через InnerTube: в ответе `next`
 * те же метки приходят урезанными и сервер отвечает на них отказом.
 * nil, если чата нет или страница не разобралась.
 */
+ (NSArray *)liveChatFiltersForVideo:(NSString *)videoId;

+ (NSDictionary *)comments:(NSString *)token;

/**
 * Та же страница, но у ветки ответов.
 *
 * Разница одна: продолжение ветки лежит в кнопке «Показать ещё ответы»,
 * и спрашивать её у перечня нельзя — там такая кнопка своя у каждой
 * ветки, и перечень ушёл бы в чужую.
 */
+ (NSDictionary *)comments:(NSString *)token replies:(BOOL)replies;

/**
 * Отправка комментария — **от имени TV-клиента, и это опыт.**
 *
 * Официально телевизор комментировать не умеет: сам YouTube на нём пишет
 * «оставьте комментарий с телефона или сайта», и панели комментариев
 * в ответе TV-клиента нет вовсе — проверено запросом. Но узел
 * `comment/create_comment` клиента не спрашивает: он проверяет метку
 * `createCommentParams` и учётную запись, а метка привязана к ролику,
 * а не к тому, кто её показал. Поэтому метку берём там, где дают
 * (WEB её кладёт в поле ввода над списком), а пишем токеном TV-клиента.
 *
 * Не выйдет — следом идут MWEB и WEB, которых удостоверяет браузерная
 * сессия. Кто из троих прошёл, видно в журнале: строка
 * `[YouTube/Комментарий] Принят … клиентом …`.
 *
 * `params` можно передать из `comments:` — тогда лишнего запроса не будет;
 * с nil метка спрашивается сама. NO, если не вошли, метки нет или все
 * трое отказали.
 */
+ (BOOL)postComment:(NSString *)text
              video:(NSString *)videoId
             params:(NSString *)params;

/**
 * То же, но с причиной отказа — той, что назвал сам сервер.
 *
 * У InnerTube отказ на запись почти всегда несёт готовую надпись для
 * человека: «комментарии отключены», «войдите в аккаунт», «слишком
 * часто». Она точнее любой нашей догадки, и показывать надо её, а не
 * пересказ. nil в `reason` означает, что сервер промолчал.
 *
 * Причина берётся от последнего отказавшего, а не от первого: первым
 * идёт TV-клиент, чей отказ и так ожидаем.
 */
+ (BOOL)postComment:(NSString *)text
              video:(NSString *)videoId
             params:(NSString *)params
             reason:(NSString **)reason;

/**
 * То же и с токеном панели комментариев.
 *
 * Метка ищется по возрастанию цены: готовая из `params`, затем по токену
 * (один запрос), затем через страницу ролика (два). У кого токен есть,
 * тому и стоит его передать.
 */
+ (BOOL)postComment:(NSString *)text
              video:(NSString *)videoId
             params:(NSString *)params
              token:(NSString *)commentsToken
             reason:(NSString **)reason;

/**
 * Ответ на чужой комментарий.
 *
 * `params` — `replyParams` из записи, которую вернул `comments:`.
 * Разговор с сервером тот же, что и у нового комментария, включая
 * перебор клиентов: узел другой, а правила те же.
 */
+ (BOOL)replyComment:(NSString *)text
              params:(NSString *)params
              reason:(NSString **)reason;

/**
 * Правка своего комментария.
 *
 * `params` — `editParams` из записи. Метку эту сервер даёт только
 * у своих записей, поэтому её наличие и есть ответ на вопрос «моё ли
 * это»: своего списка авторства у нас нет, а сверять имя канала
 * ненадёжно — имена повторяются.
 */
+ (BOOL)editComment:(NSString *)text
             params:(NSString *)params
             reason:(NSString **)reason;

/**
 * Метка для ролика отдельно — на случай, когда страницы комментариев
 * под рукой нет. Стоит двух запросов: страница ролика за токеном панели
 * и сама панель за меткой. nil означает, что писать не дают.
 */
+ (NSString *)commentParamsForVideo:(NSString *)videoId;

/**
 * То же по готовому токену панели — один запрос вместо двух.
 *
 * Метка живёт в панели комментариев, а не в странице ролика: у того,
 * у кого токен уже есть, спрашивать страницу незачем.
 */
+ (NSString *)commentParamsForToken:(NSString *)token;

/**
 * Ответ `/player` — там лежат потоки.
 *
 * Отдаётся как есть, разбирают его YTStreams и YTDashProxy: формат ответа
 * достаточно замысловат, чтобы не размазывать знание о нём по нескольким
 * местам.
 */
+ (NSDictionary *)playerResponse:(NSString *)videoId;

/**
 * Тот же ответ, но заведомо **без** подачи: ANDROID_VR и всё, что за ним.
 *
 * Нужен вторым заходом. `playerResponse:` при настройке «подача SABR»
 * отдаёт ответ TV-клиента, а годен он или нет, выясняется позже — когда
 * подачу уже спросили о первых кусках. Отказ на этом шаге лечится
 * переходом к готовым адресам, и вот за ними сюда и приходят.
 */
+ (NSDictionary *)androidVrPlayerResponse:(NSString *)videoId;

/**
 * Имя, под которым надо ходить за самими кусками видео.
 *
 * Ссылки подписаны под клиента, который их получил (`c=ANDROID_VR`
 * прямо в адресе), и CDN сверяет, тем ли клиентом за ними пришли.
 * Поэтому за кусками надо идти тем же именем, что и за ссылками.
 */
+ (NSString *)mediaUserAgent;

/** Метка сеанса воспроизведения (`cpn`) — та же, что уходит в отметки истории. */
+ (NSString *)playbackNonce;

/** Метка показа для ролика — одна на весь просмотр, как у TV-клиента. */
+ (NSString *)playbackNonceForVideo:(NSString *)videoId;

/** New viewing session; decoder/quality changes must retain the existing nonce. */
+ (void)beginPlaybackForVideo:(NSString *)videoId;

/**
 * Упёрся ли ответ `/player` в проверку «вы не робот».
 *
 * Отличать её от прочих отказов нужно потому, что лечится она иначе:
 * не повтором и не другим клиентом, а тем, что человек проходит проверку
 * в браузере. Признак — состояние `LOGIN_REQUIRED`.
 */
+ (BOOL)isBotGate:(NSDictionary *)playerResponse;

/**
 * Когда начнётся запланированная трансляция, в мировом времени.
 *
 * Ноль означает «это не будущий эфир»: обычный ролик, живая трансляция
 * или отказ по другой причине.
 */
+ (NSTimeInterval)scheduledStartIn:(NSDictionary *)json;

/** Готовая надпись ожидания из ответа сервера; пусто — её там нет. */
+ (NSString *)offlineSlateTextIn:(NSDictionary *)json;

/**
 * Лайк и подписка глазами учётной записи — ключи `liked` и `subscribed`.
 *
 * Отдельный запрос TV-клиентом: токен QR-кода сервер принимает в паре
 * именно с ним. Подмешивается к `videoDetails:`; отдельно нужен затем,
 * чтобы перечитать состояние после нажатия.
 */
+ (NSDictionary *)watchState:(NSString *)videoId;

/**
 * Отмечает ролик просмотренным — то есть кладёт его в историю.
 *
 * Отдельного запроса «добавить в историю» у InnerTube нет вовсе:
 * YouTube считает просмотр по старым служебным сигналам, тем же,
 * что шлёт youtube.com/tv. Адреса для них приходят в самом ответе
 * `/player`, уже подписанные сервером, — поэтому ответ и передаётся
 * сюда целиком, а не запрашивается заново.
 *
 * Requests enqueue immediately in viewing order; callers must not dispatch them again.
 * Сигналы уходят от имени учётной записи: этим просмотр к ней
 * и приписывается. Без входа не делается ничего.
 */
+ (void)reportWatched:(NSDictionary *)playerResponse
             position:(NSTimeInterval)position;

/**
 * Отрезок просмотра: `from`…`position`, потраченное время `elapsed`.
 *
 * `from` меньше нуля — начало показа: уходит и `playback`, и первый
 * отрезок. `final` закрывает запись: больше по этому показу ничего.
 */
+ (void)reportWatched:(NSDictionary *)playerResponse
             position:(NSTimeInterval)position
                 from:(NSTimeInterval)from
              elapsed:(NSTimeInterval)elapsed
                final:(BOOL)final;

/**
 * Незакрытая запись просмотра переживает выгрузку приложения.
 *
 * Пока ролик идёт, запись о нём лежит на устройстве: адреса сигналов,
 * докуда отчитались и докуда досмотрели. Закрывающий сигнал её стирает.
 * Если приложение сняли раньше — по нехватке памяти, — при следующем
 * запуске `flushPendingWatch` дошлёт её с тем временем, что успели
 * досмотреть. Methods enqueue their work; call directly.
 */
+ (void)notePendingWatchPosition:(NSTimeInterval)position video:(NSString *)videoId;
+ (void)flushPendingWatch;

/**
 * Подписка на канал и отказ от неё — порт `SetChannelSubscriptionAsync`.
 *
 * Клиент TVHTML5 с токеном QR-кода: та же пара, которой ходит всё
 * остальное, требующее учётной записи. `params` в оригинале берутся
 * из кнопки в ответе, а когда их там нет — подставляется постоянное
 * значение; здесь всегда оно, кнопку мы не разбираем.
 *
 * NO, если не вошли или сервер отказал.
 */
+ (BOOL)setSubscribed:(BOOL)subscribed channel:(NSString *)channelId;

/**
 * Оповещения о новых роликах канала — колокольчик у кнопки подписки.
 *
 * Три состояния, как в оригинале: все ролики, по интересам (значение
 * по умолчанию у только что оформленной подписки) и никаких.
 */
typedef enum {
    YTNotificationsUnknown = 0,
    YTNotificationsPersonalized,
    YTNotificationsAll,
    YTNotificationsNone
} YTNotifications;

/**
 * Меняет предпочтение оповещений — порт
 * `ModifyChannelNotificationPreferenceAsync`.
 *
 * Клиент TVHTML5 с токеном QR-кода, узел
 * `notification/modify_channel_preference`. NO, если не вошли
 * или сервер отказал.
 */
+ (BOOL)setNotifications:(NSInteger)state channel:(NSString *)channelId;

/**
 * Оценка ролика — порт `SetVideoRatingAsync`.
 *
 * `action`: `like`, `dislike` либо `none` (снять оценку). Клиент MWEB
 * с токеном, как в оригинале; при отказе повторяется под WEB — там
 * сказано, что некоторые учётные записи не принимают дизлайк от MWEB.
 */
+ (BOOL)rate:(NSString *)videoId as:(NSString *)action params:(NSString *)params;

/**
 * Плейлисты учётной записи для «Сохранить» — порт
 * `GetSavePlaylistStatesAsync` из UWP-оригинала.
 *
 * Каждая запись — изменяемый словарь с `playlistId`, `title`
 * и `contains` (NSNumber: лежит ли там ролик). nil — не ответил ни один
 * клиент. Пустым список не бывает: «Смотреть позже» есть у всех,
 * и ответ без единого плейлиста считается отказом.
 */
+ (NSArray *)playlistSaveStates:(NSString *)videoId;

/**
 * Кладёт ролик в плейлист или убирает из него — порт
 * `SetVideoSavedToPlaylistAsync`. «Понравившиеся» (`LL`) правятся
 * лайком, как в оригинале.
 */
+ (BOOL)setVideo:(NSString *)videoId saved:(BOOL)save inPlaylist:(NSString *)playlistId;

/**
 * Все каналы учётной записи — порт `ParseAccountInfoFromAccountsList`,
 * только там берётся один, а здесь весь список.
 *
 * У каждого: `name`, `handle`, `avatar`, `page` (кому принадлежит) и
 * `primary` — тот, который сервер считает основным. Пустой массив,
 * если не вошли.
 */
+ (NSArray *)accountsList;

/** Какой канал выбран человеком; nil — какой выберет сервер. */
+ (NSString *)activeAccountPage;
+ (void)setActiveAccountPage:(NSString *)page;

/**
 * То же, но со второй приметой того же канала.
 *
 * Сервер присылает личность канала двумя способами разом — `pageId`
 * и парой «профиль||владелец» (`datasyncIdToken`), — и какой из них
 * ждёт обратно, по ответу не видно. Шлём первый; если он не подойдёт
 * (ответ 401), в дело пойдёт второй, но только если он у нас есть.
 */
+ (void)setActiveAccountPage:(NSString *)page datasync:(NSString *)datasync;

/** Вторая примета выбранного канала; nil, если её не сохраняли. */
+ (NSString *)activeAccountDatasync;

/**
 * Примета того, от чьего имени мы сейчас говорим.
 *
 * Заведена для тех, кто по `YTAuthChangedNotification` решает, стоит ли
 * перечитывать набранное. Сверяться с одним лишь «вошли ли» мало: при
 * смене канала вход как был, так и остался, — и лента, подобранная
 * прежнему каналу, оставалась висеть у нового. Строка меняется от всякой
 * смены: и входа с выходом, и канала. Сравнивать её можно только саму
 * с собой — что внутри, значения не имеет.
 */
+ (NSString *)identityMark;

/**
 * К чему привязывать PO-токен в этом сеансе.
 *
 * У вошедшего это `datasyncId` — признак учётной записи, который сервер
 * присылает в `responseContext`; у гостя `visitorData`. Идентификатор
 * ролика сюда не годится: им привязывают токен только там, где сеанса
 * нет вовсе.
 *
 * nil, если ни того ни другого ещё не видели.
 */
+ (NSString *)sessionBinding;

/**
 * Привязка, годная для адресов **текущего** ролика, — либо nil, если
 * клиент, который их добыл, PO-токеном не пользовался.
 *
 * От `sessionBinding` отличается тем, что смотрит не на наш сеанс,
 * а на тот, которым получены ссылки: у WEB это учётная запись, у
 * ANDROID_VR — посетитель из того же запроса, у IOS — ничего.
 */
+ (NSString *)streamBinding;

/**
 * Ответ `/player` под TV-клиентом, перезапрошенный по токену подачи.
 *
 * Подача иногда отвечает «твой ответ устарел» и присылает токен вместо
 * данных. Ответ с этим токеном несёт свежие адрес подачи и настройки.
 * nil, если не вошли или сервер отказал.
 */
+ (NSDictionary *)tvPlayerResponse:(NSString *)videoId reloadToken:(NSString *)token;

/**
 * Тот же перезапрос, но **тем клиентом, чей ответ мы обновляем**.
 *
 * Подача выдана под сессию клиента, и обновлять её надо у него же.
 * Выбор здесь повторяет `playerResponse:`: TV-клиент, если вошли и
 * настройка просит подачу, иначе ANDROID_VR.
 */
+ (NSDictionary *)refreshedPlayerResponse:(NSString *)videoId
                              reloadToken:(NSString *)token;

/**
 * Номер и версия клиента для заголовков — те же, что уходят в теле.
 *
 * Открыты наружу ради подачи SABR: в её запросе надо представиться
 * **тем же** клиентом, чьим ответом получен адрес. Несовпадение версии
 * сервер встречает просьбой обновить ответ `/player` — не отказом,
 * так что по коду ответа беду не видно.
 */
+ (NSString *)clientNumber:(NSString *)client;
+ (NSString *)clientVersion:(NSString *)client;

/** Язык и страна, какими мы представляемся серверу. */
+ (NSString *)hl;
+ (NSString *)gl;

/**
 * Чем представляться подаче: описание клиента, который добыл нынешние
 * адреса потоков.
 *
 * Ключи: `number`, `version`, `osName`, `osVersion` и, если у клиента они
 * есть, `make` и `model`. Подача сверяет это с тем, кому выдан адрес;
 * несовпадение она встречает просьбой обновить ответ `/player` — без
 * единого слова о причине.
 */
+ (NSDictionary *)streamClientInfo;

/**
 * Адрес, каким нас видит Google по **свежему** ответу `/player`.
 *
 * Нужен, чтобы отличить отказ 403 из-за сменившегося выхода в сеть
 * от всех прочих: адрес раздачи подписан вместе с адресом просителя.
 * Стоит один небольшой запрос, поэтому зовётся только после отказа.
 */
+ (NSString *)probeSeenIp;

#pragma mark Shorts

/**
 * Лента Shorts. `sequence` — токен продолжения из прошлого ответа либо nil
 * для первой страницы.
 *
 * Ключи: `items` (массив YTVideoItem) и `sequence`.
 *
 * Запрос устроен не как остальные: у Shorts свои точки —
 * `reel/reel_item_watch` для первой страницы и `reel/reel_watch_sequence`
 * для следующих, — и свой набор клиентов. Всё перенесено из
 * `GetShortsAsync`, включая порядок перебора: TVHTML5, MWEB, WEB
 * с токеном, а если все отказали — WEB без него (тогда лента не
 * персональная, но она есть).
 */
+ (NSDictionary *)shorts:(NSString *)sequence;

/**
 * Потоки для Shorts. Цепочка своя — ANDROID без токена, затем WEB без
 * токена, затем WEB с токеном, — как в `PopulateShortPlaybackInfoAsync`.
 * ANDROID_VR, которым берутся потоки на странице ролика, на Shorts
 * отвечает отказом «подтвердите, что вы не бот».
 */
+ (NSDictionary *)shortsPlayerResponse:(NSString *)videoId;

/**
 * То же, но с ответом на вопрос, чем кончился перебор: `gate` получает
 * YES, если последний клиент упёрся в проверку «вы не робот». Без этого
 * отказ по проверке ничем не отличается от любого другого, а лечится
 * он единственным способом — входом в браузере.
 */
+ (NSDictionary *)shortsPlayerResponse:(NSString *)videoId gate:(BOOL *)gate;

/**
 * Всё, что нужно странице Shorts об одном ролике: `url` готового
 * склеенного потока, `title`, `channelTitle`, `channelId`.
 *
 * Лента reel присылает одни идентификаторы, поэтому подписи приезжают
 * отсюда же — из ответа `/player`, который и так нужен ради потока.
 *
 * Когда потока нет вовсе, возвращается либо nil, либо словарь с одним
 * ключом `botGate` — по нему страница показывает не пустоту, а причину.
 */
+ (NSDictionary *)shortsPlayback:(NSString *)videoId;

/**
 * Счётчики, кружок автора и метка комментариев вертикального ролика.
 *
 * Спрашивается отдельно от потока и уже после его запуска: ни одна
 * из этих цифр кадру не нужна, а стоят они двух запросов.
 * `known` — то, что уже принёс ответ `/player`.
 */
+ (NSDictionary *)shortsDetails:(NSString *)videoId known:(NSDictionary *)known;

#pragma mark Аккаунт

/** Кружок аккаунта для нижней панели; nil, если не вошли. */
+ (NSString *)accountAvatarUrl;

/**
 * Профиль вошедшего: `name`, `handle`, `avatar`, `channelId`.
 *
 * Берётся из того же `account/accounts_list`, что и кружок: там лежит
 * `accountItem` с именем и собачкой — ровно то, что показывает
 * `ApplyProfile` в Me.xaml.cs.
 */
+ (NSDictionary *)accountProfile;

/** Подписки: массив словарей с `title`, `channelId`, `thumbnail`. */
+ (NSArray *)subscriptions;

/** Лента подписок. */
+ (NSDictionary *)subscriptionsFeed:(NSString *)continuation;

/** История просмотра. */
+ (NSDictionary *)history:(NSString *)continuation;

/**
 * То же, но с разбивкой по дням: `groups` — массив `{title, items}`.
 *
 * Заголовки дней («Сегодня», «На прошлой неделе») ставит сам сервер, и их
 * может не быть — тогда всё приходит одной безымянной пачкой. Плоский
 * список и метка продолжения лежат там же, где обычно.
 */
+ (NSDictionary *)historyPage:(NSString *)continuation;

/**
 * Свои плейлисты — то, что показано полосой на вкладке «Моё».
 *
 * Массив YTVideoItem, у которых заполнен `playlistId`. Запрос тот же,
 * что в `GetMyPlaylistsViaInnertubeAsync`: `FEplaylist_aggregation`
 * у TV-клиента.
 */
+ (NSArray *)myPlaylists;

/**
 * Подборки в любом ответе — порт `ParsePlaylistCards`.
 *
 * Массив YTVideoItem с заполненным `playlistId`; в `duration` лежит
 * пометка, которую прислал сервер («Микс», «50 видео»).
 */
+ (NSArray *)playlistsIn:(id)json;

#pragma mark Канал

/**
 * Канал: шапка и первая страница роликов. Ключи: `title`, `handle`,
 * `subscribers`, `avatar`, `banner`, `description`, `items`, `continuation`.
 */
+ (NSDictionary *)channel:(NSString *)channelId tab:(NSString *)tab;

/**
 * То же, но раздел задан меткой `params` из ответа самого канала.
 *
 * Разделы у каналов разные, и метки к ним непрозрачные — вычислить их
 * нельзя, только взять из перечня, который сервер прислал вместе
 * со страницей (ключ `sections`).
 */
+ (NSDictionary *)channel:(NSString *)channelId params:(NSString *)params;

#pragma mark Подборка

/**
 * Плейлист или микс. Ключи те же, что у канала, плюс `subtitle`.
 *
 * Миксы («джемы» в терминах UWP-версии) — это подборки, которые YouTube
 * собирает на лету и продолжает бесконечно; они живут не как сохранённый
 * плейлист, а в контексте просмотра, и запрашиваются по голому
 * идентификатору. Обычным плейлистам, наоборот, нужна приставка `VL`.
 */
+ (NSDictionary *)playlist:(NSString *)playlistId;

/** Продолжение любого списка по токену. */
+ (NSDictionary *)browseContinuation:(NSString *)continuation;

/**
 * Продолжение подборки — тем же клиентом, что и её первая страница
 * (см. `playlist:`): вошедшему TV с токеном, гостю WEB.
 */
+ (NSDictionary *)playlistContinuation:(NSString *)continuation;

@end
