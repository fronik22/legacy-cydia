"""Extract exact character metadata from two owner-supplied game bundles."""
import sys,json,hashlib
from pathlib import Path
import UnityPy
paths=[Path(x) for x in sys.argv[1:]];assert len(paths)==3
assert not paths[2].exists(),'Refusing overwrite'
expected={'base':'d043ee3bf55f6c671360e0306bb0703563cd8144060919d12b099d840e08ce6c','ext':'b598d535c97a77822a6ce00ee53cafe0acb5c0f98cf914fea453b440fc2cb227'}
result=[];seen=set()
for path in paths[:2]:
 for o in UnityPy.load(str(path)).objects:
  if o.type.name!='TextAsset':continue
  d=o.read()
  if d.m_Name not in expected:continue
  raw=d.m_Script.encode('utf-8','surrogateescape') if isinstance(d.m_Script,str) else d.m_Script
  assert hashlib.sha256(raw).hexdigest()==expected[d.m_Name],'Unsupported character database'
  assert d.m_Name not in seen;seen.add(d.m_Name);result+=json.loads(raw)
assert seen==set(expected),'Missing base/ext character data'
paths[2].parent.mkdir(parents=True,exist_ok=True);paths[2].write_text(json.dumps(result));print('Verified character parts',len(result))
