import os,tempfile,unittest
from pathlib import Path
import server as s
from unittest.mock import patch

class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();s.DB=Path(self.tmp.name)/'game.db';s.initialize()
  self.body={'udid':'owned-test-device'}
  self.login=s.route('POST','/kabam/register',{},self.body)
  self.q={'stoken':[self.login['stoken']]}
 def tearDown(self):self.tmp.cleanup()
 def call(self,path,body=None):return s.route('POST' if body is not None else 'GET',path,self.q,body or {})
 def test_identity_and_saves(self):
  other=s.route('POST','/kabam/guest',{},self.body)
  self.assertEqual(other['user']['uid'],self.login['user']['uid'])
  uid=str(other['user']['uid']);self.call('/ds/'+uid,{'data':{'profile':{'coins':123}}})
  self.assertEqual(self.call('/ds/'+uid)['profile']['coins'],123)
  with self.assertRaises(s.APIError):self.call('/ds/99')
 def test_nonce_wallet_atomic(self):
  start=self.call('/wallet/balance')['balance'];body={'value':40,'nonce':'once'}
  self.call('/wallet/debit',body);self.call('/wallet/debit',body)
  self.assertEqual(self.call('/wallet/balance')['balance'],start-40)
  with self.assertRaises(s.APIError):self.call('/wallet/debit',{'value':-1})
  with self.assertRaises(s.APIError):self.call('/wallet/debit',{'value':30,'nonce':'once'})
 def test_free_credit_idempotence_and_wallet_push(self):
  start=self.call('/wallet/balance')['balance'];messages=[]
  s.PUSHES.register(self.login['user']['uid'],lambda op,data:messages.append((op,data)))
  try:
   body={'value':100,'reason':'revival-free-store','nonce':'free-pack'}
   self.call('/wallet/credit',body);self.call('/wallet/credit',body)
   self.assertEqual(self.call('/wallet/balance')['balance'],start+100)
   s.PUSHES.wallet_sync(self.login['stoken']);s.PUSHES.wallet_sync('invalid')
   self.assertEqual(messages,[(1,b'{"component":"WalletManager","message":"sync"}')])
  finally:s.PUSHES.remove(self.login['user']['uid'],s.PUSHES.sessions[self.login['user']['uid']])
 def test_inventory_and_rejection_rollback(self):
  key=next(iter(s.ITEMS));before=self.call('/inventory').get(key,0)
  self.call('/inventory/add',{'items':{key:2},'nonce':'items'})
  self.assertEqual(self.call('/inventory')[key],before+2)
  balance=self.call('/wallet/balance')['balance']
  with self.assertRaises(s.APIError):self.call('/inventory/purchase',{'cost':1,'items':{'invalid-item':1}})
  self.assertEqual(self.call('/wallet/balance')['balance'],balance)
 def test_loot_nonce_and_debit(self):
  table=self.call('/gacha/getSet');body={'group':'base','set':table['name'],'version':table['version'],'box':'token_bronze','payment':'','nonce':'spin'}
  before=self.call('/wallet/balance')['balance'];inventory=self.call('/inventory');result=self.call('/gacha/pick',body)
  self.assertEqual(self.call('/gacha/pick',body),result)
  self.assertEqual(self.call('/wallet/balance')['balance'],before-5)
  self.assertEqual(self.call('/inventory')[result['data']],inventory.get(result['data'],0)+result['quantity'])
 def test_canonical_keys(self):
  self.assertEqual(s.safe_key("Elephant Gun"),'elephantgun')
  self.assertEqual(s.safe_key("Cupidtron's Crossbow"),'cupidtronscrossbow')
 def test_robot_part_purchase(self):
  self.assertIn('robot_head',s.PARTS)
  before=self.call('/wallet/balance')['balance']
  self.call('/inventory/purchase',{'items':{'robot_head':1},'cost':2,'nonce':'robot'})
  self.assertEqual(self.call('/inventory')['robot_head'],1)
  self.assertEqual(self.call('/wallet/balance')['balance'],before-2)
 def test_session(self):
  with self.assertRaises(s.APIError):s.route('GET','/inventory',{}, {})
  with self.assertRaises(s.APIError):self.call('/unknown')
 def test_connections_closed_after_success_and_error(self):
  opened=[];connect=s.sqlite3.connect
  def tracked(*args,**kwargs):
   db=connect(*args,**kwargs);opened.append(db);return db
  try:
   with patch.object(s.sqlite3,'connect',tracked):
    for _ in range(50):self.call('/inventory')
    self.assertEqual(s.route('POST','/kabam/guest',{},self.body)['user']['uid'],self.login['user']['uid'])
    with self.assertRaises(s.APIError):self.call('/inventory/purchase',{'items':{'unknown':1},'cost':1})
    s.game_usage(self.login['user']['uid'],'closure-test',begin=True)
    s.game_usage(self.login['user']['uid'],'closure-test',end=True)
   for db in opened:
    with self.assertRaises(s.sqlite3.ProgrammingError):db.execute('SELECT 1')
  finally:
   for db in opened:db.close()


class GameInventoryTests(unittest.TestCase):
 call=Tests.call
 tearDown=Tests.tearDown
 def setUp(self):
  Tests.setUp(self)
  self.uid=self.login['user']['uid'];self.session='owned-game-session'
  self.key='rocket';self.other='teleportgrenade'
  self.assertIn(self.other,s.VALID_ITEMS)
  self.other_initial=self.call('/inventory').get(self.other,0)+3
  self.call('/inventory/add',{'items':{self.other:3}})
  s.game_usage(self.uid,self.session,begin=True)
  self.used=0
 def spend(self,count):
  self.used+=count
  s.game_usage(self.uid,self.session,{self.key:count})
 def displayed(self):return self.call('/inventory').get(self.key,0)-self.used
 def test_last_unit_then_first_purchase(self):
  initial=self.displayed();self.spend(initial)
  self.assertEqual(self.displayed(),0)
  result=self.call('/inventory/add',{'items':{self.key:8},'nonce':'in-match-buy'})
  self.assertEqual(result[self.key]-self.used,8)
  self.assertEqual(self.call('/inventory')[self.other],self.other_initial)
  self.assertEqual(self.call('/inventory/add',{'items':{self.key:8},'nonce':'in-match-buy'}),result)
  self.assertEqual(self.displayed(),8)
  self.spend(1);self.assertEqual(self.displayed(),7)
 def test_purchase_before_spend_and_full_use_snapshot(self):
  initial=self.displayed();self.call('/inventory/purchase',{'items':{self.key:8},'cost':2,'nonce':'hard-buy'})
  self.spend(1);self.assertEqual(self.displayed(),initial+7)
  snapshot=self.call('/inventory/use',{'items':{self.other:1},'nonce':'direct-use'})
  self.assertIn(self.key,snapshot);self.assertEqual(snapshot[self.other],self.other_initial-1)
  self.assertEqual(snapshot[self.key]-self.used,initial+7)
 def test_rematch_close_and_relogin(self):
  initial=self.displayed();self.spend(1)
  # start/end on the same socket do not reset native cumulative usage.
  self.spend(1);self.assertEqual(self.displayed(),initial-2)
  messages=[];s.PUSHES.register(self.uid,lambda op,data:messages.append((op,data)))
  try:
   s.close_game_usage(self.uid,self.session);s.close_game_usage(self.uid,self.session)
   self.assertEqual(len(messages),1)
   self.assertEqual(messages[0][1],b'{"component":"InventoryManager","message":"sync"}')
   self.used=0;self.assertEqual(self.displayed(),initial-2)
   login=s.route('POST','/kabam/guest',{},self.body)
   self.assertEqual(login['data']['inventory'][self.key],initial-2)
  finally:
   with s.PUSHES.lock:s.PUSHES.sessions.pop(self.uid,None)
 def test_old_socket_cannot_clear_new_session(self):
  s.game_usage(self.uid,'new-session',begin=True)
  s.close_game_usage(self.uid,self.session)
  with self.assertRaises(s.APIError):s.game_usage(self.uid,self.session,{self.key:1})
  s.game_usage(self.uid,'new-session',{self.key:1})
 def test_invalid_spend_rolls_back(self):
  before=self.call('/inventory')
  with self.assertRaises(s.APIError):s.game_usage(self.uid,self.session,{self.key:1,'unknown':1})
  self.assertEqual(self.call('/inventory'),before)
  with self.assertRaises(s.APIError):s.game_usage(self.uid,self.session,{self.key:10000})
 def test_restart_keeps_spending_not_stale_ledger(self):
  initial=self.displayed();self.spend(1);s.initialize();self.used=0
  self.assertEqual(self.displayed(),initial-1)

if __name__=='__main__':unittest.main()
