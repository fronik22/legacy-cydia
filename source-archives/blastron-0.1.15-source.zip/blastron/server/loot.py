"""Small revival loot table; original commercial probabilities are unavailable."""
import secrets

VERSION = 'revival-2'
TOKEN = 'token_bronze'
COST = 5

def table(group, items):
    if group not in ('base', 'tutorial'): raise ValueError('unknown_group')
    prizes = [{'id': key, 'type': 'inventory', 'data': key} for key, item in items.items()
              if item.get('c', 0) == 0 and item.get('l', 1) <= 2 and not item.get('ih')][:8]
    if not prizes: raise ValueError('no_loot_items')
    box = {'name': 'token_bronze' if group == 'base' else 'token_tutorial', 'token': TOKEN,
           'multiplier': 1, 'minLevel': 0, 'hc': {'cost': COST, 'xp': 0}, 'tokenc': {'cost': 1, 'xp': 0},
           'displayname': {'en': 'Revival crate', 'ru': 'Ящик'}, 'possiblePrizes': prizes}
    return {'name': group, 'version': VERSION, 'attracts': [p['data'] for p in prizes], 'possiblePrizes': prizes, 'boxes': [box]}

def pick(state, body, items):
    group = body.get('group')
    data = table(group, items)
    if body.get('set') != data['name'] or body.get('version') != VERSION:
        raise ValueError('outdated_loot_table')
    if body.get('box') not in ('token_bronze', 'token_tutorial', 'tutorial'):
        raise ValueError('unknown_box')
    tokens = state.setdefault('tokens', {TOKEN: 1})
    if body.get('payment') == 'token':
        if tokens.get(TOKEN, 0) < 1: raise ValueError('nsf')
        tokens[TOKEN] -= 1
    elif body.get('payment', '') == '':
        if state['balance'] < COST: raise ValueError('nsf')
        state['balance'] -= COST
    else: raise ValueError('invalid_payment')
    prize = secrets.choice(data['possiblePrizes'])
    key = prize['data']; quantity = 5
    state['inventory'][key] = state['inventory'].get(key, 0) + quantity
    return {'type': 'inventory', 'data': key, 'quantity': quantity, 'balance': tokens[TOKEN], 'softToPay': 0, 'xpToGive': 0}
