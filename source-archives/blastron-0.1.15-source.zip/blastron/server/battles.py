"""One human host plus three native Blastron AI opponents per match."""
import copy, json, secrets, struct, threading, time

class BattleError(ValueError): pass

class Battles:
    def __init__(self, base, on_use=None):
        self.base = base
        self.on_use = on_use
        self.games = {}
        self.lock = threading.RLock()

    def create(self, uid, token, attributes, player):
        if not isinstance(attributes, dict) or not isinstance(player, dict):
            raise BattleError('invalid_match')
        if not isinstance(player.get('recipe'), dict):
            raise BattleError('missing_robot_recipe')
        defaults = {'Mode': 'MP', 'GameMode': 'DeathMatch', 'Order': '0', 'AuxFlags': 'kNone', 'Championship': 'kOff'}
        for key in ('Level', 'Version', 'Mode', 'GameMode', 'Order', 'AuxFlags', 'Championship'):
            value = attributes.get(key, defaults.get(key, ''))
            if not isinstance(value, (str, int)) or len(str(value)) > 1024:
                raise BattleError('invalid_attributes')
            defaults[key] = str(value)
        if not defaults['Level'].startswith('level_'):
            raise BattleError('invalid_level')
        if defaults['GameMode'] not in ('DeathMatch', 'TeamDeathMatch', 'KillCount', 'SuddenDeath'):
            defaults['GameMode'] = 'DeathMatch'
        defaults['Mode'] = 'MP'
        roster = [{'id': 1, 'uid': uid, 'attributes': copy.deepcopy(player)}]
        for index in range(3):
            bot = copy.deepcopy(player)
            bot.update(name='Bot ' + str(index + 1), ai=True)
            bot.pop('fbid', None)
            roster.append({'id': 10 + index, 'uid': uid, 'attributes': bot})
        key = secrets.token_urlsafe(18)
        game = {'uid': uid, 'token': token, 'attributes': defaults, 'roster': roster, 'created': time.time(), 'started': False}
        with self.lock:
            self.games = {k: v for k, v in self.games.items() if time.time() - v['created'] < 7200}
            if len(self.games) >= 64: raise BattleError('match_limit')
            self.games[key] = game
        return {'gameId': secrets.randbelow(2**30) + 1, 'connId': 1, 'url': self.base + '/game/' + key + '?stoken=' + token}

    def get(self, key, uid, token):
        with self.lock:
            game = self.games.get(key)
            if game is None or game['uid'] != uid or not secrets.compare_digest(game['token'], token):
                raise BattleError('invalid_match')
            return game

    @staticmethod
    def command(name, value=None):
        text = name + (':' + json.dumps(value, separators=(',', ':')) if value is not None else '')
        return b'\x00' + text.encode()

    def receive(self, game, data, usage_session=None):
        if not data: raise BattleError('empty_packet')
        channel = data[0] & 15
        if channel > 3: raise BattleError('invalid_channel')
        offset = 5 if data[0] & 64 else 1
        if len(data) < offset: raise BattleError('short_packet')
        if data[0] & 64:
            target = struct.unpack('<I', data[1:5])[0]
            return [data] if target == 1 else []
        if data[0] & 128 or channel >= 2:
            body = data[offset:]
            # The host simulates bots, but the remote load barrier still expects their acknowledgements.
            if channel == 2 and body.startswith(b'\x011\x00') and len(body) >= 13 and body[7:9] == b'\x01\x06':
                return [b'\x42' + struct.pack('<I', bot['id']) + body[:9] + struct.pack('<I', bot['id'])
                        for bot in game['roster'][1:]]
            # Network-created AI does not run the campaign's SetLoadout path.
            ready = b'\x017\x00'
            at = body.find(ready)
            if channel == 2 and at >= 0 and body[at+7:].startswith(b'\x01\x0cOnNetworkLoadedLevel\x00'):
                rpc = b'\x017\x00' + struct.pack('<I', 0) + b'\x01\x0cOrderBotArsenal\x00'
                return [b'\x42' + struct.pack('<I', 1) + rpc]
            # Echoing the host's own broadcasts would duplicate scene creation and RPCs.
            return []
        command, _, payload = data[offset:].decode().partition(':')
        value = json.loads(payload) if payload else None
        with self.lock:
            if command == 'hello':
                return [self.command('attributes', game['attributes']), self.command('roster', game['roster'])]
            if command == 'attributes':
                if not isinstance(value, dict) or len(value) > 32: raise BattleError('invalid_attributes')
                game['attributes'].update(value)
                return [self.command('attributes', game['attributes'])]
            if command == 'playerattributes':
                if not isinstance(value, dict) or len(value) > 64: raise BattleError('invalid_player_attributes')
                game['roster'][0]['attributes'].update(value)
                return [self.command('roster', game['roster']), self.command('attributes', game['attributes'])]
            if command in ('start', 'end'):
                game['started'] = command == 'start'
                return [self.command(command, value)]
            if command == 'kick':
                game['roster'] = [p for p in game['roster'] if p['id'] != value or p['id'] == 1]
                return [self.command('roster', game['roster'])]
            if command == 'use':
                if self.on_use is None or usage_session is None:
                    raise BattleError('missing_inventory_session')
                self.on_use(game['uid'], usage_session, value)
                return []
            raise BattleError('unsupported_game_command:' + command)
