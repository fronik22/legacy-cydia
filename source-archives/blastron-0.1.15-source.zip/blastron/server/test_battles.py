import unittest,json,struct
from battles import Battles,BattleError
class Tests(unittest.TestCase):
 def setUp(self):
  self.b=Battles('ws://127.0.0.1:18080')
  self.result=self.b.create(1,'owned-token',{'Level':'level_asia_garden','Version':'test'}, {'name':'Pilot','recipe':{'parts':[1,2,3]}})
  key=self.result['url'].split('/game/')[1].split('?')[0]
  self.game=self.b.get(key,1,'owned-token')
 def test_roster(self):
  packets=self.b.receive(self.game,b'\x00hello')
  self.assertEqual(len(packets),2)
  roster=json.loads(packets[1].split(b':',1)[1]);self.assertEqual(len(roster),4)
  self.assertTrue(all(p['attributes']['ai'] for p in roster[1:]))
 def test_replication(self):
  self.assertEqual(self.b.receive(self.game,b'\x82rpc'),[])
  direct=b'\x42'+struct.pack('<I',1)+b'rpc'
  self.assertEqual(self.b.receive(self.game,direct),[direct])
 def test_bot_load_acknowledgements(self):
  body=b'\x011\x00'+struct.pack('<I',123)+b'\x01\x06'+struct.pack('<I',1)
  replies=self.b.receive(self.game,b'\x82'+body)
  self.assertEqual(len(replies),3)
  self.assertEqual([struct.unpack('<I',p[1:5])[0] for p in replies],[10,11,12])
  self.assertEqual([struct.unpack('<I',p[-4:])[0] for p in replies],[10,11,12])
 def test_arsenal_initialization(self):
  body=b'\x017\x00'+struct.pack('<I',123)+b'\x01\x0cOnNetworkLoadedLevel\x00'
  replies=self.b.receive(self.game,b'\x82'+body)
  self.assertEqual(len(replies),1)
  self.assertTrue(replies[0].endswith(b'OrderBotArsenal\x00'))
  self.assertEqual(self.b.receive(self.game,b'\x82'+body.replace(b'Level',b'Other')),[])
 def test_lifecycle(self):
  self.b.receive(self.game,b'\x00start');self.assertTrue(self.game['started'])
  self.b.receive(self.game,b'\x00end');self.assertFalse(self.game['started'])
 def test_use_is_recorded_without_http_echo(self):
  spent=[];self.b.on_use=lambda uid,session,items:spent.append((uid,session,items))
  self.assertEqual(self.b.receive(self.game,b'\x00use:{"rocket":1}','session'),[])
  self.assertEqual(spent,[(1,'session',{'rocket':1})])
 def test_validation(self):
  with self.assertRaises(BattleError):self.b.create(1,'x',{'Level':'bad'},{'recipe':{}})
  with self.assertRaises(BattleError):self.b.receive(self.game,b'\x42x')
  with self.assertRaises(BattleError):self.b.get('missing',2,'x')
if __name__=='__main__':unittest.main()
