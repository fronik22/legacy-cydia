"""Private Blastron 2.x compatibility backend. No real purchases or original accounts."""
import base64, hashlib, http.server, json, os, secrets, socket, socketserver, sqlite3, struct, threading, time, re, contextlib
from pathlib import Path
from battles import Battles, BattleError
import loot
from urllib.parse import urlsplit, parse_qs

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / 'config.json').read_text())
DB = Path(os.environ.get('BLASTRON_DB', '/var/lib/blastron/game.sqlite3'))
CATALOG = json.loads((ROOT / 'catalog.json').read_text())
def safe_key(value):
    return re.sub('[^a-z0-9/_]', '', value.lower())

ITEMS = {safe_key(x['n']): x for x in CATALOG}
PARTS = {safe_key(x['n']): x for x in json.loads((ROOT / 'parts.json').read_text())}
VALID_ITEMS = ITEMS.keys() | PARTS.keys()
START = {safe_key(x['n']): x['sc'] for x in CATALOG if x.get('sc', 0) > 0}
BASE = CONFIG['endpoint'].rstrip('/')
WS = BASE.replace('http://', 'ws://')

class APIError(Exception):
    pass

class PushSessions:
    def __init__(self):
        self.lock = threading.Lock()
        self.sessions = {}
    def register(self, uid, send):
        with self.lock: self.sessions[uid] = send
    def remove(self, uid, send):
        with self.lock:
            if self.sessions.get(uid) is send: self.sessions.pop(uid)
    def wallet_sync(self, token):
        with connection() as db:
            row=db.execute('SELECT uid FROM players WHERE token=?',(token,)).fetchone()
        if row is None:return
        with self.lock:send=self.sessions.get(row['uid'])
        if send:
            try:send(1,b'{"component":"WalletManager","message":"sync"}')
            except OSError:self.remove(row['uid'],send)
    def inventory_sync(self, uid):
        with self.lock: send = self.sessions.get(uid)
        if send:
            try:
                send(1, b'{"component":"InventoryManager","message":"sync"}')
                print(json.dumps({'event': 'inventory_sync_push', 'uid': uid}), flush=True)
            except OSError: self.remove(uid, send)

PUSHES = PushSessions()

@contextlib.contextmanager
def connection():
    db = sqlite3.connect(DB, timeout=10)
    try:
        db.row_factory = sqlite3.Row
        # sqlite3's transaction context commits/rolls back but does not close.
        with db:
            yield db
    finally:
        db.close()

def initialize():
    DB.parent.mkdir(parents=True, exist_ok=True)
    with connection() as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('CREATE TABLE IF NOT EXISTS players(uid INTEGER PRIMARY KEY, device TEXT UNIQUE, token TEXT UNIQUE, state TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS nonces(uid INTEGER, nonce TEXT, digest TEXT, result TEXT, PRIMARY KEY(uid,nonce))')
        for row in db.execute('SELECT uid,state FROM players').fetchall():
            state = json.loads(row['state'])
            normalized = {}
            for key, count in state['inventory'].items():
                canonical = safe_key(key)
                if canonical in normalized and normalized[canonical] != count:
                    raise ValueError('Conflicting legacy inventory keys; preserve database and inspect manually')
                normalized[canonical] = count
            stale_usage = state.pop('gameUsage', None)
            if normalized != state['inventory'] or stale_usage is not None:
                state['inventory'] = normalized
                db.execute('UPDATE players SET state=? WHERE uid=?', (json.dumps(state), row['uid']))


def bootstrap(body):
    device = body.get('udid')
    if not isinstance(device, str) or not 4 <= len(device) <= 200:
        raise APIError('invalid_device')
    key = hashlib.sha256(device.encode()).hexdigest()
    with connection() as db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT * FROM players WHERE device=?', (key,)).fetchone()
        if row is None:
            if db.execute('SELECT count(*) FROM players').fetchone()[0] >= 64:
                raise APIError('player_limit')
            state = {'name': 'Blastron Pilot', 'inventory': START, 'balance': 1000,
                     'ds': {'profile': {'coins': 5000, 'xp': 0}}}
            db.execute('INSERT INTO players(device,token,state) VALUES(?,?,?)', (key, secrets.token_urlsafe(32), json.dumps(state)))
            row = db.execute('SELECT * FROM players WHERE device=?', (key,)).fetchone()
        state = json.loads(row['state'])
        if state.pop('gameUsage', None) is not None:
            db.execute('UPDATE players SET state=? WHERE uid=?', (json.dumps(state), row['uid']))
            row = db.execute('SELECT * FROM players WHERE uid=?', (row['uid'],)).fetchone()
        return row

def masters(token):
    return [{'name': 'Revival', 'endpoint': WS + '/master?stoken=' + token,
             'token': token, 'pingPort': CONFIG['port']}]

def login(row, state):
    token = row['token']
    return {'naid': str(row['uid']), 'country': 'RU', 'fbAppId': '', 'salt': '', 'stoken': token,
            'user': {'uid': row['uid'], 'name': state['name']},
            'data': {'inventory': state['inventory'], 'wallet': {'balance': state['balance']}, 'ds': state['ds'],
                     'master': masters(token), 'push': {'websocket': WS + '/push?stoken=' + token},
                     'tele': {'interval': 3600, 'filter': ['']}}}

def positive(value, maximum=100000):
    if type(value) is not int or value < 0 or value > maximum:
        raise APIError('invalid_quantity')
    return value

def wire_inventory(state):
    # Native GetCount subtracts its cumulative _used until the game socket closes.
    result = dict(state['inventory'])
    for key, used in state.get('gameUsage', {}).get('items', {}).items():
        result[key] = result.get(key, 0) + used
    return result

def game_usage(uid, session, items=None, *, begin=False, end=False):
    with connection() as db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT state FROM players WHERE uid=?', (uid,)).fetchone()
        if row is None: raise APIError('invalid_user')
        state = json.loads(row['state'])
        ledger = state.get('gameUsage', {})
        if begin:
            state['gameUsage'] = {'session': session, 'items': {}}
        elif ledger.get('session') != session:
            if end: return False
            raise APIError('stale_game_connection')
        elif end:
            state.pop('gameUsage')
        else:
            if not isinstance(items, dict) or not 1 <= len(items) <= 128:
                raise APIError('invalid_items')
            for key, count in items.items():
                if key not in VALID_ITEMS: raise APIError('unknown_item')
                count = positive(count, 10000)
                remaining = state['inventory'].get(key, 0) - count
                if remaining < 0: raise APIError('nsf')
                state['inventory'][key] = remaining
                ledger['items'][key] = ledger['items'].get(key, 0) + count
        db.execute('UPDATE players SET state=? WHERE uid=?', (json.dumps(state), uid))
    if items is not None:
        print(json.dumps({'event': 'inventory_spend', 'uid': uid, 'items': items}), flush=True)
    return True

def close_game_usage(uid, session):
    if game_usage(uid, session, end=True):
        # Standard Sparx notification refreshes the menu after local _used clears.
        PUSHES.inventory_sync(uid)

BATTLES = Battles(WS, game_usage)

def route(method, path, query, body):
    if path == '/content' and method == 'GET':
        return {}
    if path == '/health' and method == 'GET':
        return {'service': 'blastron', 'version': '0.1.3', 'status': 'research'}
    if path in ('/kabam/register', '/kabam/guest') and method == 'POST':
        row = bootstrap(body)
        return login(row, json.loads(row['state']))
    token = query.get('stoken', [''])[0]
    with connection() as db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT * FROM players WHERE token=?', (token,)).fetchone()
        if row is None:
            raise APIError('invalid_session')
        state = json.loads(row['state'])
        nonce = body.get('nonce')
        digest = hashlib.sha256(json.dumps([method, path, body], sort_keys=True).encode()).hexdigest()
        if nonce is not None:
            if not isinstance(nonce, str) or not 1 <= len(nonce) <= 200:
                raise APIError('invalid_nonce')
            old = db.execute('SELECT * FROM nonces WHERE uid=? AND nonce=?', (row['uid'], nonce)).fetchone()
            if old:
                if old['digest'] != digest:
                    raise APIError('nonce_conflict')
                return json.loads(old['result'])
        if path == '/kabam/name' and method == 'POST':
            name = body.get('name', '')
            if not isinstance(name, str) or not 1 <= len(name.strip()) <= 32:
                raise APIError('invalid_name')
            state['name'] = name.strip()
            result = login(row, state)
        elif path == '/inventory' and method == 'GET':
            result = wire_inventory(state)
        elif path in ('/inventory/add', '/inventory/use', '/inventory/purchase') and method == 'POST':
            items = body.get('items')
            if not isinstance(items, dict) or len(items) > 128:
                raise APIError('invalid_items')
            if path.endswith('purchase'):
                cost = positive(body.get('cost', 0), 10000000)
                if cost > state['balance']:
                    raise APIError('nsf')
                state['balance'] -= cost
            result = {}
            for key, count in items.items():
                if not isinstance(key, str) or key not in VALID_ITEMS:
                    raise APIError('unknown_item')
                count = positive(count, 10000)
                before = state['inventory'].get(key, 0)
                after = before - count if path.endswith('use') else before + count
                if not 0 <= after <= 100000:
                    raise APIError('nsf')
                state['inventory'][key] = after
            snapshot = wire_inventory(state)
            # OnSync replaces the entire inventory; OnAdd/OnPurchase merge keys.
            result = snapshot if path.endswith('use') else {key: snapshot[key] for key in items}
            if path.endswith('purchase'):
                result['__wallet'] = {'balance': state['balance']}
        elif path == '/wallet/balance' and method == 'GET':
            result = {'balance': state['balance']}
        elif path in ('/wallet/credit', '/wallet/debit') and method == 'POST':
            value = positive(body.get('value', 0), 1000000)
            balance = state['balance'] + (value if path.endswith('credit') else -value)
            if not 0 <= balance <= 10000000:
                raise APIError('nsf')
            state['balance'] = balance
            result = {'balance': balance}
        elif path.startswith('/ds/'):
            parts = path.strip('/').split('/')
            if len(parts) < 2 or parts[1] != str(row['uid']):
                raise APIError('invalid_user')
            if method == 'POST' and len(parts) == 2:
                data = body.get('data')
                if not isinstance(data, dict) or len(data) > 128:
                    raise APIError('invalid_save')
                state['ds'].update(data)
                result = {}
            elif method == 'GET':
                key = parts[2] if len(parts) > 2 else ''
                result = {key: state['ds'].get(key, {})} if key else state['ds']
            else:
                raise APIError('unsupported_method')
        elif path == '/tuning': result = []
        elif path == '/master/list': result = masters(token)
        elif path == '/push/token': result = {'websocket': WS + '/push?stoken=' + token}
        elif path == '/gacha/getTokens': result = [{'token': k, 'count': v} for k, v in state.setdefault('tokens', {loot.TOKEN: 1}).items()]
        elif path == '/gacha/getTimestamp': result = {'version': loot.VERSION}
        elif path == '/gacha/getSet': result = loot.table(query.get('group', ['base'])[0], ITEMS)
        elif path == '/gacha/addtoken' and method == 'POST':
            if body.get('token') != loot.TOKEN: raise APIError('unknown_token')
            tokens = state.setdefault('tokens', {loot.TOKEN: 1})
            result = tokens[loot.TOKEN] = min(1000, tokens.get(loot.TOKEN, 0) + 1)
        elif path == '/gacha/pick' and method == 'POST': result = loot.pick(state, body, ITEMS)
        elif path == '/messenger/count': result = 0
        elif path == '/messenger/motd': result = None
        elif path in ('/tournaments/active', '/store/offers', '/store/payouts'): result = {}
        elif path in ('/telemetry', '/util/ping', '/push/apple', '/gamecenter/id', '/tournaments/report'): result = {}
        else: raise APIError('unsupported_endpoint')
        db.execute('UPDATE players SET state=? WHERE uid=?', (json.dumps(state), row['uid']))
        if nonce is not None:
            db.execute('INSERT INTO nonces VALUES(?,?,?,?)', (row['uid'], nonce, digest, json.dumps(result)))
        return result

class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = 'BlastronRevival/0.1'
    def log_message(self, *args): pass
    def setup(self):
        super().setup()
        self.connection.settimeout(30)
    def do_GET(self): self.handle_api()
    def do_POST(self): self.handle_api()
    def handle_api(self):
        url = urlsplit(self.path)
        path = '/' + url.path.lstrip('/')
        prefix = urlsplit(BASE).path.rstrip('/')
        if prefix and path.startswith(prefix + '/'):
            path = path[len(prefix):]
        query = parse_qs(url.query)
        status = 200
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if length < 0 or length > 262144: raise APIError('invalid_length')
            body = json.loads(self.rfile.read(length)) if length else {}
            if not isinstance(body, dict): raise APIError('invalid_json')
            if self.headers.get('Upgrade', '').lower() == 'websocket':
                return self.websocket(path, query)
            result = route(self.command, path, query, body)
            if path == '/wallet/credit' and self.command == 'POST':PUSHES.wallet_sync(query.get('stoken',[''])[0])
            payload = {'result': result, 'err': None, 'ts': int(time.time())}
            print(json.dumps({'event': 'api', 'method': self.command, 'path': path, 'keys': sorted(body), 'ok': True}), flush=True)
        except (APIError, ValueError, UnicodeError) as ex:
            payload = {'result': {'fatal': False, 'retry': False}, 'err': str(ex), 'ts': int(time.time())}
            print(json.dumps({'event': 'api', 'method': self.command, 'path': path, 'error': str(ex)}), flush=True)
        data = json.dumps(payload, separators=(',', ':')).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Connection', 'close')
        self.end_headers(); self.wfile.write(data); self.close_connection = True
    def websocket(self, path, query):
        with connection() as db:
            row = db.execute('SELECT uid,token FROM players WHERE token=?', (query.get('stoken', [''])[0],)).fetchone()
        key = self.headers.get('Sec-WebSocket-Key', '')
        if not row or (path not in ('/push', '/master') and not path.startswith('/game/')) or len(key) > 100:
            self.send_error(403); return
        game = BATTLES.get(path.split('/')[-1], row['uid'], row['token']) if path.startswith('/game/') else None
        self.send_response(101)
        self.send_header('Upgrade', 'websocket'); self.send_header('Connection', 'Upgrade')
        self.send_header('Sec-WebSocket-Accept', base64.b64encode(hashlib.sha1((key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode())
        protocol = self.headers.get('Sec-WebSocket-Protocol')
        if protocol in ('io.sparx.push', 'io.sparx.master-client', 'io.sparx.game'):
            self.send_header('Sec-WebSocket-Protocol', protocol)
        self.end_headers(); self.wfile.flush()
        self.connection.settimeout(180)
        print(json.dumps({'event': 'websocket', 'path': path}), flush=True)
        send_lock = threading.Lock()
        def send(op, data):
            size = len(data)
            header = bytes([0x80 | op, size]) if size < 126 else (bytes([0x80 | op, 126]) + struct.pack('!H', size) if size < 65536 else bytes([0x80 | op, 127]) + struct.pack('!Q', size))
            with send_lock:
                self.wfile.write(header + data); self.wfile.flush()
        usage_session = secrets.token_hex(16) if game is not None else None
        try:
            if path == '/push': PUSHES.register(row['uid'], send)
            if usage_session is not None:
                game_usage(row['uid'], usage_session, begin=True)
            while True:
                h = self.rfile.read(2)
                if len(h) != 2: break
                op, size = h[0] & 15, h[1] & 127
                if not h[1] & 128: break
                if size == 126: size = struct.unpack('!H', self.rfile.read(2))[0]
                elif size == 127: size = struct.unpack('!Q', self.rfile.read(8))[0]
                if size > 262144: break
                mask = self.rfile.read(4); data = self.rfile.read(size)
                if len(mask) != 4 or len(data) != size: break
                data = bytes(x ^ mask[i % 4] for i, x in enumerate(data))
                if op == 8: send(8, b''); break
                if op == 9: send(10, data)
                if op == 1 and path == '/master':
                    message = json.loads(data)
                    print(json.dumps({'event': 'rpc', 'name': message[2]}), flush=True)
                    result, error = None, None
                    try:
                        if message[2] == 'listGames': result = []
                        elif message[2] == 'findOrCreate':
                            result = BATTLES.create(row['uid'], row['token'], message[3][1]['attributes'], message[3][2])
                        elif message[2] == 'resetServer':
                            result = BATTLES.create(row['uid'], row['token'], message[3][0]['attributes'], message[3][1])
                        elif message[2] == 'find': error = 'No public human matches; use Quick Play for bots'
                        else: error = 'Unsupported matchmaking request'
                    except (BattleError, KeyError, IndexError, TypeError) as ex: error = str(ex)
                    send(1, json.dumps([1, message[1], error, result]).encode())
                if op == 2 and game is not None:
                    try:
                        packets = BATTLES.receive(game, data, usage_session)
                        if len(packets) == 3: print(json.dumps({'event': 'bot_load_ready', 'count': 3}), flush=True)
                        if any(packet.endswith(b'OrderBotArsenal\x00') for packet in packets): print(json.dumps({'event': 'bot_arsenal_ready'}), flush=True)
                        for packet in packets: send(2, packet)
                    except (BattleError, APIError) as ex:
                        print(json.dumps({'event': 'game_error', 'error': str(ex)}), flush=True)
                        send(8, b''); break
        except (OSError, ValueError, IndexError): pass
        finally:
            if path == '/push': PUSHES.remove(row['uid'], send)
            if usage_session is not None:
                close_game_usage(row['uid'], usage_session)
        self.close_connection = True

class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True
    slots = threading.BoundedSemaphore(24)
    def process_request(self, request, address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try: super().process_request(request, address)
        except Exception:
            self.slots.release()
            raise
    def process_request_thread(self, request, address):
        try: super().process_request_thread(request, address)
        finally: self.slots.release()

class Qos(socketserver.BaseRequestHandler):
    def handle(self):
        data, sock = self.request
        if len(data) == 128:
            sock.sendto(b'{"g":0,"p":0}', self.client_address)

if __name__ == '__main__':
    initialize()
    udp = socketserver.UDPServer(('0.0.0.0', CONFIG['port']), Qos)
    threading.Thread(target=udp.serve_forever, daemon=True).start()
    print('Blastron research service ready', flush=True)
    Server(('0.0.0.0', CONFIG['port']), Handler).serve_forever()
