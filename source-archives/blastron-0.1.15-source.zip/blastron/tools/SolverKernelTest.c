#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#define BOOL bool
#define YES true
#define NO false
#include "../src/SolverKernel.h"
_Static_assert(sizeof(SConstraint)==84,"native constraint layout");
_Static_assert(sizeof(SPoint)==36,"native point layout");
_Static_assert(sizeof(SVelocity)==12,"native velocity layout");
static void readExact(FILE *f,void *out,size_t bytes){assert(fread(out,1,bytes,f)==bytes);}
int main(int argc,char **argv){
 assert(argc==2);FILE *f=fopen(argv[1],"rb");assert(f);int header[2];readExact(f,header,8);int n=header[0],length=header[1];assert(n>0&&n<=256&&length>0&&length<=512);
 SVelocity input[512],prediction[512],actual[512];SConstraint cs[256];SPoint points[256][2],predictedPoints[256][2],actualPoints[256][2];
 readExact(f,input,length*12);readExact(f,cs,n*84);readExact(f,points,n*72);readExact(f,prediction,length*12);readExact(f,predictedPoints,n*72);readExact(f,actual,length*12);readExact(f,actualPoints,n*72);assert(fgetc(f)==EOF);fclose(f);
 for(int i=0;i<n;i++)assert(cs[i].a>=0&&cs[i].a<length&&cs[i].b>=0&&cs[i].b<length&&cs[i].pointCount>=1&&cs[i].pointCount<=2);
 unsigned cases[5]={0};SolveValues(input,cs,points,n,cases);assert(!memcmp(input,actual,length*12));assert(!memcmp(prediction,actual,length*12));
 for(int i=0;i<n;i++)for(int j=0;j<cs[i].pointCount;j++){assert(!memcmp(&points[i][j],&actualPoints[i][j],36));assert(!memcmp(&predictedPoints[i][j],&actualPoints[i][j],36));}
 printf("{\"contacts\":%d,\"velocities\":%d,\"native_bytes_match\":true,\"cases\":[%u,%u,%u,%u,%u]}\n",n,length,cases[0],cases[1],cases[2],cases[3],cases[4]);return 0;
}
