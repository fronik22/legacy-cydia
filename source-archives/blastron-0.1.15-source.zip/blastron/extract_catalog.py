"""Extract inventorydb from an owner's Blastron inventory assetbundle; no game assets shipped."""
import hashlib,json,sys
from pathlib import Path
import UnityPy
source,output=map(Path,sys.argv[1:])
assert not output.exists(),'Refusing to overwrite existing catalog'
for obj in UnityPy.load(str(source)).objects:
 if obj.type.name!='TextAsset':continue
 data=obj.read()
 if data.m_Name!='inventorydb':continue
 raw=data.m_Script
 if isinstance(raw,str):raw=raw.encode('utf-8','surrogateescape')
 assert hashlib.sha256(raw).hexdigest()=='57487bbae47b2f94da955c2af0e561549e446d13c501254c49c5121f81637fa6','Unsupported inventory database'
 assert isinstance(json.loads(raw),list)
 output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(raw);print('Extracted verified catalog');break
else:raise SystemExit('inventorydb TextAsset not found')
