from pathlib import Path
import os, subprocess, sys

ROOT = Path(__file__).resolve().parent
SDK = Path(os.environ['IOS_SDK'])
STUB = Path(os.environ.get('IOS_STUB', str(SDK)))
SIGNER = os.environ['IOS_LDID']
B = ROOT / 'build'
B.mkdir(exist_ok=True)
name = sys.argv[1]
kind = {'PerfControl': 'exe', 'PurchaseTrace': 'bundle', 'TaskPC': 'exe', 'TaskThreads': 'exe', 'Launch': 'exe', 'Shot': 'exe', 'Touch': 'exe', 'SmoothTouch': 'exe', 'Inspect': 'bundle', 'BackgroundTest': 'bundle', 'Probe': 'bundle', 'SoundProbe': 'bundle', 'SoundInventory': 'bundle', 'SoundWatch': 'bundle', 'TallyCheck': 'bundle', 'SoundHotfix': 'bundle', 'Screen': 'bundle', 'Setup': 'exe', 'VeterisIPad': 'dylib', 'Client': 'dylib'}[name]
source = ROOT / ('tools' if name in ('PerfControl', 'PurchaseTrace', 'TaskPC', 'TaskThreads', 'Launch', 'Touch', 'Shot', 'Inspect', 'BackgroundTest', 'Probe', 'Screen', 'SmoothTouch', 'SoundProbe', 'SoundInventory', 'SoundWatch', 'TallyCheck', 'SoundHotfix') else 'src') / (name + '.m')
output = B / (name + {'exe': '', 'bundle': '.bundle', 'dylib': '.dylib'}[kind])
commands = [
    ['xcrun', 'clang', '-target', 'armv7-apple-ios5.0', '-isysroot', SDK, '-fno-objc-arc', '-fblocks', *(['-DBLASTRON_UI_TEST_DRIVER'] if name=='Client' and os.environ.get('BLASTRON_UI_TEST_DRIVER')=='1' else []), *(['-DBLASTRON_EXPERIMENTAL_ROTATION'] if name=='Client' and os.environ.get('BLASTRON_EXPERIMENTAL_ROTATION')=='1' else []), *(['-DBLASTRON_EXPERIMENTAL_SOLVER'] if name=='Client' and os.environ.get('BLASTRON_EXPERIMENTAL_SOLVER')=='1' else []), *(['-DBLASTRON_GL_TRACE'] if name=='Client' and os.environ.get('BLASTRON_GL_TRACE')=='1' else []), *(['-DBLASTRON_BENCH_PAIRS'] if name=='Client' and os.environ.get('BLASTRON_BENCH_PAIRS')=='1' else []), '-Os', '-ffp-contract=off', '-Wno-deprecated-declarations', '-c', source, '-o', B / (name + '.o')],
    ['xcrun', 'ld-classic', '-arch', 'armv7', '-iphoneos_version_min', '5.0', '-syslibroot', STUB, '-L' + str(STUB / 'usr/lib'), '-o', output,
     *({'exe': ['-no_pie', SDK / 'usr/lib/crt1.3.1.o'], 'bundle': ['-bundle'], 'dylib': ['-dylib', '-install_name', '/Library/MobileSubstrate/DynamicLibraries/BlastronRevival.dylib']}[kind]), B / (name + '.o'),
     '-framework', 'Foundation', '-framework', 'CoreFoundation', '-framework', 'UIKit', '-framework', 'CoreGraphics', '-framework', 'QuartzCore', '-lobjc', '-lSystem', '-lgcc_s.1'],
    [SIGNER, '-Cadhoc', '-Hsha1', '-S' + str(ROOT / 'tools/launch-entitlements.plist') if name == 'Launch' else '-S' + str(ROOT / 'tools/task-read-entitlements.plist') if name in ('TaskThreads','TaskPC') else '-S', output],
]
for i, args in enumerate(commands):
    p = subprocess.run(list(map(str, args)), capture_output=True, text=True)
    (B / (name + '-' + str(i) + '.log')).write_text(p.stdout + p.stderr)
    if p.returncode:
        raise RuntimeError(p.stderr[-4000:])
print(output)
