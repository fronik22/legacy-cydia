"""Package only our reversible setup and compatibility tweak, never game files."""
from pathlib import Path
import shutil,plistlib,json
from package_deb import build_deb
R=Path(__file__).resolve().parent; B=R/'build'; version='0.1.15'
stage,control=B/'stage',B/'control'
for p in (stage,control):shutil.rmtree(p,ignore_errors=True);p.mkdir(parents=True)
def write(path,data,mode=0o644):
 p=stage/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(mode)
write('Library/MobileSubstrate/DynamicLibraries/BlastronRevival.dylib',(B/'Client.dylib').read_bytes())
write('Library/MobileSubstrate/DynamicLibraries/BlastronRevival.plist',plistlib.dumps({'Filter':{'Bundles':['com.kabam.blastbots']}}))
write('usr/libexec/blastron-revival-setup',(B/'Setup').read_bytes(),0o755)
config=R/'config.json' if (R/'config.json').exists() else R/'config.private.json'
endpoint=json.loads(config.read_text())['endpoint'].ljust(27,'/')
assert len(endpoint.encode('ascii'))==27
write('usr/share/blastron-revival/endpoint.plist',plistlib.dumps({'endpoint':endpoint}))
write('usr/share/doc/local.codex.blastron-revival/COPYING',(R/'COPYING').read_bytes())
write('usr/share/doc/local.codex.blastron-revival/README',b'Experimental Blastron2.2.0 revival for jailbroken iOS6. Original endpoint resource is backed up and restored on removal. Own guest profile, inventory and bot backend; no original accounts, human matchmaking or real purchases. Backend uses unencrypted HTTP for legacy compatibility: play on a trusted network. Exact executable required for native AI loadout fix. Runs only inside the game; bounded logs and local command-file polling4/s while active. No daemon or SpringBoard hooks. Game assets/executable are not redistributed.\n')
(control/'control').write_text(f'''Package: local.codex.blastron-revival
Name: Blastron Revival
Version: {version}
Architecture: iphoneos-arm
Maintainer: Legacy iPad Tools
Author: Legacy iPad Tools
Section: Tweaks
Depends: firmware (>= 6.0), firmware (<< 7.0), mobilesubstrate
Description: Experimental Blastron2.2.0 private backend and native bot loadout fix.
 Reversible endpoint redirect, missing AI ammunition initialization, and
 obsolete service suppression. Requires the exact supported Blastron build.
''')
(control/'postinst').write_text('''#!/bin/sh
set -e
case "$1" in
 configure)
  /usr/bin/killall blastbots >/dev/null 2>&1 || true
  /usr/libexec/blastron-revival-setup apply
 ;;
esac
''')
(control/'prerm').write_text('''#!/bin/sh
set -e
case "$1" in
 remove|deconfigure)
  /usr/bin/killall blastbots >/dev/null 2>&1 || true
  /usr/libexec/blastron-revival-setup remove
 ;;
esac
''')
for name in ('postinst','prerm'):(control/name).chmod(0o755)
build_deb(stage,control,R/('dist/blastron-revival_'+version+'_iphoneos-arm.deb'))
