"""Portable regression against an actual native shadow input/output, no game assets."""
from pathlib import Path
import json,subprocess,tempfile,unittest
R=Path(__file__).resolve().parent
class SolverKernelTest(unittest.TestCase):
 def test_native_numeric_fixture(self):
  with tempfile.TemporaryDirectory() as d:
   binary=Path(d)/'solver'
   subprocess.run(['clang','-std=c11','-O2','-ffp-contract=off',str(R/'tools/SolverKernelTest.c'),'-o',str(binary)],check=True,capture_output=True)
   result=subprocess.run([str(binary),str(R/'tests/solver-fixture.bin')],check=True,capture_output=True,text=True)
   self.assertTrue(json.loads(result.stdout)['native_bytes_match'])
if __name__=='__main__':unittest.main()
