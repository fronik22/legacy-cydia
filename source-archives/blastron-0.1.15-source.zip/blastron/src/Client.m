#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <CommonCrypto/CommonDigest.h>
#import <CoreFoundation/CoreFoundation.h>
#import <QuartzCore/QuartzCore.h>
#include <limits.h>
// Addresses derived from this exact executable's AOT method table and IL tokens.
static intptr_t GameSlide;
static void (*OriginalOrderArsenal)(void *,void *);
static void OrderArsenal(void *self,void *weapons) {
    // Native OrderArsenal reads _sLoadout even when called with _botWeapons.
    // The remote-MP path never calls SetLoadout; preserve any real SP loadout.
    void **field=*(void ***)(GameSlide+0x13acd14);
    if(field && !*field && weapons) {
        *field=weapons; // Same store as the original AISimple.SetLoadout.
        NSLog(@"BlastronRevival: initialized missing AI ammunition loadout");
    }
    OriginalOrderArsenal(self,weapons);
}
// Mono's armv7 value-type ABI flattens ViewId(p,n,bool+padding) into three words.
static void (*OriginalCallViewRPC)(unsigned,unsigned,void*,unsigned,unsigned,unsigned,void*);
static unsigned BotEvents[3][2];
static NSString *ManagedString(void *s);
static void Event(NSString *event,NSDictionary *values);
static void CallViewRPC(unsigned sender,unsigned sequence,void *name,unsigned owner,unsigned objectID,unsigned flags,void *arguments) {
    if(sender==1 && owner>=10 && owner<=12) {
        // Local bot RPCs must allocate projectiles with the bot as instantiator.
        // This is exactly the client's IsLocalGame branch in ViewRPC.
        sender=owner;
        int length=name?*(int*)((char*)name+8):0;
        if(length>0 && length<64) {
            NSString *method=[NSString stringWithCharacters:(unichar*)((char*)name+12) length:length];
            int event=[method isEqual:@"FireRPC"]?0:([method isEqual:@"Blast"]?1:-1);
            if(event>=0 && BotEvents[owner-10][event]++<16)NSLog(@"BlastronRevival: bot %u %@ with correct instantiator",owner,method);
        }
    }
    NSString *method=ManagedString(name);
    if([@[@"FireRPC",@"Blast",@"SelectWeaponRPC",@"ApplyHit"] containsObject:method])
        Event(@"combat_rpc",@{@"method":method,@"sender":@(sender),@"owner":@(owner),@"object":@(objectID)});
    OriginalCallViewRPC(sender,sequence,name,owner,objectID,flags,arguments);
}
static BOOL ExactExecutable(void) {
    NSData *data=[NSData dataWithContentsOfFile:[NSBundle mainBundle].executablePath];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];CC_SHA256(data.bytes,(CC_LONG)data.length,digest);
    NSMutableString *hex=[NSMutableString string];for(int i=0;i<sizeof(digest);i++)[hex appendFormat:@"%02x",digest[i]];
    return [hex isEqual:@"17296e736b52b10c13a819d9160aeb8aa0e924daf7cf96b6194165a9b834e1d7"];
}
typedef struct {const char *text,*placeholder;int type,correction,multiline;bool secure,alert;} KeyboardShowParam;
_Static_assert(sizeof(KeyboardShowParam)==24,"Unity4 armv7 keyboard ABI");
static void (*OriginalShowKeyboard)(id,SEL,KeyboardShowParam);
static void ShowKeyboard(id self,SEL cmd,KeyboardShowParam parameters) {
    OriginalShowKeyboard(self,cmd,parameters);
    // Unity4 owns these UIKit input objects; normalize only its nonsecure text input.
    const char *names[]={"textField","textView"};
    for(int i=0;i<2;i++) {
        Ivar ivar=class_getInstanceVariable([self class],names[i]);
        id field=ivar?object_getIvar(self,ivar):nil;
        if(!field)continue;
        NSInteger type=[field keyboardType];BOOL secure=[field isSecureTextEntry];
        NSLog(@"BlastronRevival: Unity keyboard %@ type=%ld secure=%d parameter=%d",NSStringFromClass([field class]),(long)type,secure,parameters.type);
        if(!secure && type!=UIKeyboardTypeNumberPad && type!=UIKeyboardTypePhonePad && type!=UIKeyboardTypeDecimalPad) {
            [field setKeyboardType:UIKeyboardTypeDefault];
            if([field isFirstResponder])[field reloadInputViews];
        }
    }
}
#include "Gameplay.inc"
static void LegacyTelemetry(id self, SEL cmd, id token) {}
static void RemoteNotifications(id self, SEL cmd, NSUInteger types) {
    // The revival uses its own push WebSocket; Apple registration has no consumer.

}
static void GameCenter(id self, SEL cmd, void(^completion)(NSError *)) {
    if(!completion)return;
    BOOL authenticated=[self respondsToSelector:NSSelectorFromString(@"isAuthenticated")] && ((BOOL(*)(id,SEL))objc_msgSend)(self,NSSelectorFromString(@"isAuthenticated"));
    dispatch_async(dispatch_get_main_queue(),^{
        completion(authenticated?nil:[NSError errorWithDomain:@"GKErrorDomain" code:2 userInfo:nil]);
    });
}
__attribute__((constructor)) static void Start(void) {
    NSAutoreleasePool *pool=[NSAutoreleasePool new];
    NSDictionary *info=[NSBundle mainBundle].infoDictionary;
    if([[info objectForKey:@"CFBundleIdentifier"] isEqual:@"com.kabam.blastbots"] && [[info objectForKey:@"CFBundleVersion"] isEqual:@"2.2.0"]) {
        void *lib=dlopen("/usr/lib/libsubstrate.dylib",RTLD_LAZY|RTLD_LOCAL);
        void(*hook)(Class,SEL,IMP,IMP*)=lib?dlsym(lib,"MSHookMessageEx"):NULL;
        Class classes[3]={[UIApplication class],NSClassFromString(@"GKLocalPlayer"),object_getClass(NSClassFromString(@"TestFlight"))};
        SEL selectors[3]={NSSelectorFromString(@"registerForRemoteNotificationTypes:"),NSSelectorFromString(@"authenticateWithCompletionHandler:"),NSSelectorFromString(@"takeOff:")};
        IMP replacements[3]={(IMP)RemoteNotifications,(IMP)GameCenter,(IMP)LegacyTelemetry};
        int changed=0;
        for(int i=0;hook&&i<3;i++){
            Method method=class_getInstanceMethod(classes[i],selectors[i]);
            if(method&&method_getNumberOfArguments(method)==3&&method_getTypeEncoding(method)[0]=='v') {hook(classes[i],selectors[i],replacements[i],NULL);changed++;}
        }
        NSLog(@"BlastronRevival: legacy service hooks %d/3",changed);
        void(*hookFunction)(void*,void*,void**)=lib?dlsym(lib,"MSHookFunction"):NULL;
        if(hookFunction && ExactExecutable()) {
            Class keyboard=NSClassFromString(@"KeyboardDelegate");
            SEL show=NSSelectorFromString(@"show:");
            Method method=class_getInstanceMethod(keyboard,show);
            if(hook && method && strcmp(method_getTypeEncoding(method),"v32@0:4{KeyboardShowParam=**iiiBB}8")==0) {
                hook(keyboard,show,(IMP)ShowKeyboard,(IMP*)&OriginalShowKeyboard);
                NSLog(@"BlastronRevival: native Unity keyboard hook installed");
            }else NSLog(@"BlastronRevival: refused unknown Unity keyboard signature");
            GameSlide=_dyld_get_image_vmaddr_slide(0);
            GameplayHooks(hookFunction);
            hookFunction((void*)(GameSlide+0x3914d4),(void*)OrderArsenal,(void**)&OriginalOrderArsenal);
            hookFunction((void*)(GameSlide+0x65dfc),(void*)CallViewRPC,(void**)&OriginalCallViewRPC);
            NSLog(@"BlastronRevival: exact-build AI ammunition and projectile ownership fixes installed");
        }else NSLog(@"BlastronRevival: AI fix refused unsupported executable");
    }
    [pool drain];
}
