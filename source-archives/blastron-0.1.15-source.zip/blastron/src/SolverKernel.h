// Value-only contact velocity solver, preserving exact-build double expressions
// and every float local/vector rounding boundary. No time/accuracy changes.
typedef struct {float x,y;} SV;
typedef struct {SV v;float w;} SVelocity;
typedef struct {SV rA,rB;float normalImpulse,tangentImpulse,normalMass,tangentMass,velocityBias;} SPoint;
typedef struct {SV normal,mass[2],K[2];int a,b;float mA,mB,iA,iB,friction,restitution,tangentSpeed;int pointCount,contactIndex;} SConstraint;
static inline SV sa(SV a,SV b){return (SV){(float)((double)a.x+b.x),(float)((double)a.y+b.y)};}
static inline SV ss(SV a,SV b){return (SV){(float)((double)a.x-b.x),(float)((double)a.y-b.y)};}
static inline SV sm(float a,SV b){return (SV){(float)((double)a*b.x),(float)((double)a*b.y)};}
static inline SV sn(SV a){return (SV){-a.x,-a.y};}
static inline SV scv(SV a,float s){return (SV){(float)((double)s*a.y),(float)(-(double)s*a.x)};}
static inline SV scs(float s,SV a){return (SV){(float)(-(double)s*a.y),(float)((double)s*a.x)};}
static inline float sd(SV a,SV b){return (float)((double)a.x*b.x+(double)a.y*b.y);}
static inline float sc(SV a,SV b){return (float)((double)a.x*b.y-(double)a.y*b.x);}
static inline SV sMat(const SV a[2],SV v){return (SV){(float)((double)a[0].x*v.x+(double)a[1].x*v.y),(float)((double)a[0].y*v.x+(double)a[1].y*v.y)};}
static inline SV sDV(SV va,float wa,SV vb,float wb,const SPoint *p){return ss(ss(sa(vb,scs(wb,p->rB)),va),scs(wa,p->rA));}
static inline void sApply(const SConstraint *c,const SPoint *p,SV impulse,SV *va,float *wa,SV *vb,float *wb){
 *va=ss(*va,sm(c->mA,impulse));*wa=(float)((double)*wa-(double)c->iA*sc(p->rA,impulse));
 *vb=sa(*vb,sm(c->mB,impulse));*wb=(float)((double)*wb+(double)c->iB*sc(p->rB,impulse));
}
static void SolveValues(SVelocity *vel,SConstraint *cs,SPoint (*ps)[2],int count,unsigned cases[5]){
 for(int i=0;i<count;i++){
  SConstraint *c=cs+i;SPoint *p=ps[i];SV va=vel[c->a].v,vb=vel[c->b].v;float wa=vel[c->a].w,wb=vel[c->b].w;SV tangent=scv(c->normal,1.f);
  for(int j=0;j<c->pointCount;j++){
   SPoint *q=p+j;float vt=(float)((double)sd(sDV(va,wa,vb,wb,q),tangent)-c->tangentSpeed);
   float lambda=(float)((double)q->tangentMass*-(double)vt),limit=(float)((double)c->friction*q->normalImpulse);
   float sum=(float)((double)q->tangentImpulse+lambda),clamped=sum<limit?sum:limit;clamped=clamped< -limit?-limit:clamped;
   lambda=(float)((double)clamped-q->tangentImpulse);q->tangentImpulse=clamped;sApply(c,q,sm(lambda,tangent),&va,&wa,&vb,&wb);
  }
  if(c->pointCount==1){
   float vn=sd(sDV(va,wa,vb,wb,p),c->normal);
   float lambda=(float)(-(double)p->normalMass*((double)vn-p->velocityBias));
   float sum=(float)((double)p->normalImpulse+lambda),next=sum>0?sum:0.f;
   lambda=(float)((double)next-p->normalImpulse);p->normalImpulse=next;sApply(c,p,sm(lambda,c->normal),&va,&wa,&vb,&wb);cases[0]++;
  }else{
   SV old={p[0].normalImpulse,p[1].normalImpulse};
   SV b={(float)((double)sd(sDV(va,wa,vb,wb,p),c->normal)-p[0].velocityBias),(float)((double)sd(sDV(va,wa,vb,wb,p+1),c->normal)-p[1].velocityBias)};
   b=ss(b,sMat(c->K,old));SV next=sn(sMat(c->mass,b));BOOL apply=NO;unsigned branch=1;
   if(next.x>=0&&next.y>=0)apply=YES;
   else{
    next=(SV){(float)(-(double)p[0].normalMass*b.x),0};float vn=(float)((double)c->K[0].y*next.x+b.y);branch=2;
    if(next.x>=0&&vn>=0)apply=YES;
    else{
     next=(SV){0,(float)(-(double)p[1].normalMass*b.y)};vn=(float)((double)c->K[1].x*next.y+b.x);branch=3;
     if(next.y>=0&&vn>=0)apply=YES;
     else{next=(SV){0,0};branch=4;if(b.x>=0&&b.y>=0)apply=YES;}
    }
   }
   if(apply){
    SV delta=ss(next,old),one=sm(delta.x,c->normal),two=sm(delta.y,c->normal),total=sa(one,two);
    va=ss(va,sm(c->mA,total));wa=(float)((double)wa-(double)c->iA*((double)sc(p[0].rA,one)+sc(p[1].rA,two)));
    vb=sa(vb,sm(c->mB,total));wb=(float)((double)wb+(double)c->iB*((double)sc(p[0].rB,one)+sc(p[1].rB,two)));
    p[0].normalImpulse=next.x;p[1].normalImpulse=next.y;cases[branch]++;
   }
  }
  vel[c->a]=(SVelocity){va,wa};vel[c->b]=(SVelocity){vb,wb};
 }
}
