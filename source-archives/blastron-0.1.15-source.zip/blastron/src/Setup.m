#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <sys/stat.h>
#import <unistd.h>
#import <errno.h>
static NSString *const State=@"/var/lib/blastron-revival";
static NSString *const StockSHA=@"64efbaa58d0be07fe7ad07ce38fbf69125fa5410d79f7080db05a5fed3c11392";
static const NSUInteger Offset=516252, Length=27, FileSize=517288;
static void Fail(NSString *message){@throw [NSException exceptionWithName:@"BlastronRevival" reason:message userInfo:nil];}
static NSString *SHA(NSData *data){unsigned char digest[CC_SHA256_DIGEST_LENGTH];CC_SHA256(data.bytes,(CC_LONG)data.length,digest);NSMutableString *s=[NSMutableString string];for(int i=0;i<sizeof(digest);i++)[s appendFormat:@"%02x",digest[i]];return s;}
static NSData *Replace(NSData *data,NSString *url){NSData *bytes=[url dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:NO];if(data.length!=FileSize||bytes.length!=Length)Fail(@"Unsupported resource size or endpoint length");NSMutableData *copy=[[data mutableCopy] autorelease];[copy replaceBytesInRange:NSMakeRange(Offset,Length) withBytes:bytes.bytes];return copy;}
static void Regular(NSString *path){struct stat st;if(lstat(path.fileSystemRepresentation,&st)||!S_ISREG(st.st_mode))Fail(@"Expected a regular file");}
static void Write(NSData *data,NSString *path){if(![data writeToFile:path atomically:YES])Fail(@"Atomic write failed");}
int main(int argc,char **argv){NSAutoreleasePool *pool=[NSAutoreleasePool new];int result=1;
 @try {
  if(getuid()!=0||argc!=2)Fail(@"Run as root: apply, remove or --self-test");
  NSString *mode=[NSString stringWithUTF8String:argv[1]];if(![mode isEqual:@"apply"]&&![mode isEqual:@"remove"]&&![mode isEqual:@"--self-test"])Fail(@"Unknown action");
  NSDictionary *sys=[NSDictionary dictionaryWithContentsOfFile:@"/System/Library/CoreServices/SystemVersion.plist"];if(![[sys objectForKey:@"ProductVersion"] hasPrefix:@"6."])Fail(@"This package targets iOS6; other versions require validation");
  NSFileManager *fm=[NSFileManager defaultManager];NSString *base=@"/var/mobile/Applications",*app=nil;
  for(NSString *name in [fm contentsOfDirectoryAtPath:base error:nil]){
   NSString *candidate=[[base stringByAppendingPathComponent:name] stringByAppendingPathComponent:@"blastbots.app"];
   NSDictionary *info=[NSDictionary dictionaryWithContentsOfFile:[candidate stringByAppendingPathComponent:@"Info.plist"]];
   if([[info objectForKey:@"CFBundleIdentifier"] isEqual:@"com.kabam.blastbots"]&&[[info objectForKey:@"CFBundleVersion"] isEqual:@"2.2.0"]){if(app)Fail(@"Multiple matching apps");app=candidate;}
  }
  if(!app)Fail(@"Install Blastron2.2.0 first");
  if(![SHA([NSData dataWithContentsOfFile:[app stringByAppendingPathComponent:@"blastbots"]]) isEqual:@"17296e736b52b10c13a819d9160aeb8aa0e924daf7cf96b6194165a9b834e1d7"])Fail(@"Unsupported Blastron executable; exact build required");
  NSString *target=[app stringByAppendingPathComponent:@"Data/mainData"],*saved=[State stringByAppendingPathComponent:@"mainData.original"],*manifest=[State stringByAppendingPathComponent:@"state.plist"];
  Regular(target);struct stat attrs;if(stat(target.fileSystemRepresentation,&attrs))Fail(@"Cannot inspect app resource");
  NSString *endpoint=[[NSDictionary dictionaryWithContentsOfFile:@"/usr/share/blastron-revival/endpoint.plist"] objectForKey:@"endpoint"];
  if(![endpoint isKindOfClass:[NSString class]]||![endpoint hasPrefix:@"http://"]||[endpoint lengthOfBytesUsingEncoding:NSASCIIStringEncoding]!=Length)Fail(@"Invalid endpoint configuration");
  NSDictionary *prior=[NSDictionary dictionaryWithContentsOfFile:manifest];NSData *current=[NSData dataWithContentsOfFile:target],*original=nil;
  struct stat st;BOOL exists=lstat(State.fileSystemRepresentation,&st)==0;
  if(exists&&(!S_ISDIR(st.st_mode)||st.st_uid!=0||(st.st_mode&0022)))Fail(@"Unsafe backup directory");
  if([fm fileExistsAtPath:saved]){Regular(saved);original=[NSData dataWithContentsOfFile:saved];}
  else original=Replace(current,@"https://api.rivets.sparx.io");
  if(![[SHA(original) lowercaseString] isEqual:StockSHA])Fail(@"Unsupported or altered Blastron resource; nothing overwritten");
  NSString *previous=[prior objectForKey:@"endpoint"]?:endpoint;
  if(prior&&![[prior objectForKey:@"app"] isEqual:app])Fail(@"App moved; preserve the backup and inspect manually");
  if(![current isEqual:original]&&![current isEqual:Replace(original,previous)])Fail(@"External resource changes detected; nothing overwritten");
  if([mode isEqual:@"--self-test"]){NSData *patched=Replace(original,endpoint);if(![Replace(patched,@"https://api.rivets.sparx.io") isEqual:original])Fail(@"Reversibility check failed");puts("PASS: exact original, supported target, reversible endpoint patch");result=0;}
  else if([mode isEqual:@"apply"]){
   if(!exists&&![fm createDirectoryAtPath:State withIntermediateDirectories:NO attributes:[NSDictionary dictionaryWithObject:[NSNumber numberWithInt:0700] forKey:NSFilePosixPermissions] error:nil])Fail(@"Cannot create backup directory");
   if(![fm fileExistsAtPath:saved]){Write(original,saved);chmod(saved.fileSystemRepresentation,0600);}
   NSDictionary *record=[NSDictionary dictionaryWithObjectsAndKeys:app,@"app",endpoint,@"endpoint",StockSHA,@"originalSHA256",nil];
   if(![record writeToFile:manifest atomically:YES])Fail(@"Cannot save restore metadata");chmod(manifest.fileSystemRepresentation,0600);
   Write(Replace(original,endpoint),target);chown(target.fileSystemRepresentation,attrs.st_uid,attrs.st_gid);chmod(target.fileSystemRepresentation,attrs.st_mode&0777);puts("Applied Blastron revival endpoint; original resource preserved");result=0;
  }else{
   if(!prior)Fail(@"No installed backup metadata; refusing removal");
   Write(original,target);chown(target.fileSystemRepresentation,attrs.st_uid,attrs.st_gid);chmod(target.fileSystemRepresentation,attrs.st_mode&0777);
   [fm removeItemAtPath:manifest error:nil];[fm removeItemAtPath:saved error:nil];rmdir(State.fileSystemRepresentation);puts("Original Blastron endpoint restored");result=0;
  }
 }@catch(NSException *e){fprintf(stderr,"%s\n",e.reason.UTF8String);}
 [pool drain];return result;
}
