from pathlib import Path
import os,subprocess
ROOT=Path(__file__).resolve().parents[1];B=ROOT/'build/runtime';SRC=Path(os.environ.get('LEGACY_CPP_SOURCE',str(ROOT if (ROOT/'vendor').exists() else ROOT.parent/'unlocalsend-ios4')));SDK=Path(os.environ['IOS4_SDK']);STUB=Path(os.environ.get('IOS4_STUB',str(ROOT/'build/sdk')));LDID=os.environ['IOS4_LDID']
def run(cmd):
 p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stderr[-5000:])
for name in ['shared_check','shared_plugin']:
 run(['xcrun','clang++','-target','armv7-apple-ios4.3','-isysroot',SDK,'-nostdinc++','-std=c++11','-I'+str(SRC/'vendor/libcxx-3.5-headers/include'),'-Wno-deprecated-builtins','-Wno-reserved-user-defined-literal','-Os','-c',ROOT/'runtime'/(name+'.cpp'),'-o',B/(name+'.o')])
 flags=['xcrun','ld-classic','-arch','armv7','-iphoneos_version_min','4.3','-syslibroot',STUB,'-L'+str(B),'-L'+str(STUB/'usr/lib'),'-o',B/(name+('.dylib' if name=='shared_plugin' else ''))]
 if name=='shared_plugin':flags+=['-dylib']
 else:flags+=['-no_pie',SDK/'usr/lib/crt1.3.1.o']
 run(flags+[B/(name+'.o'),'-lc++','-lgcc_s.1','-lSystem'])
 run([LDID,'-Cadhoc','-Hsha1','-S',B/(name+('.dylib' if name=='shared_plugin' else ''))])
print('Built shared-library client and cross-module exception fixture')

run(['xcrun','clang','-target','armv7-apple-ios4.3','-isysroot',SDK,'-Os','-c',ROOT/'runtime/loader_check.c','-o',B/'loader_check.o'])
run(['xcrun','ld-classic','-arch','armv7','-iphoneos_version_min','4.3','-no_pie','-syslibroot',STUB,'-L'+str(STUB/'usr/lib'),'-o',B/'loader_check',SDK/'usr/lib/crt1.3.1.o',B/'loader_check.o','-lSystem','-lgcc_s.1'])
run([LDID,'-Cadhoc','-Hsha1','-S',B/'loader_check'])
