#include <memory>
#include <string>
#include <vector>
#include <stdexcept>
#include <thread>
#include <mutex>
#include <cassert>
#include <dlfcn.h>
#include <cstdio>
int main(int argc,char **argv){
    auto p=std::make_shared<std::string>("shared libc++");std::vector<std::shared_ptr<std::string>> v(4,p);assert(p.use_count()==5 && *v[2]=="shared libc++");
    bool caught=false;try{throw std::runtime_error("expected");}catch(const std::exception &e){caught=std::string(e.what())=="expected";}assert(caught);
    int count=0;std::mutex m;std::thread t([&]{std::lock_guard<std::mutex> guard(m);++count;});t.join();assert(count==1);
    void *old=dlopen("/usr/lib/libstdc++.6.dylib",RTLD_NOW|RTLD_LOCAL);assert(old);
    if(argc==2){void *plugin=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);if(!plugin){fprintf(stderr,"%s\n",dlerror());return 2;}auto call=(void (*)())dlsym(plugin,"throw_from_plugin");assert(call);caught=false;try{call();}catch(const std::exception &e){caught=std::string(e.what())=="plugin exception";}assert(caught);dlclose(plugin);}
    std::puts("PASS shared runtime: ownership, strings/vector, exceptions, mutex/thread, libstdc++ coexistence and plugin ABI");
}
