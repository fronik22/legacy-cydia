#include <dlfcn.h>
#include <stdio.h>
int main(){
 void *legacy=dlopen("/usr/lib/libstdc++.6.dylib",RTLD_NOW|RTLD_LOCAL);if(!legacy){puts(dlerror());return 1;}
 void *cpp=dlopen("/usr/lib/libc++.1.dylib",RTLD_NOW|RTLD_LOCAL);if(!cpp){puts(dlerror());return 2;}
 void *abi=dlopen("/usr/lib/libc++abi.dylib",RTLD_NOW|RTLD_LOCAL);if(!abi){puts(dlerror());return 3;}
 void *symbol=dlsym(cpp,"__cxa_throw");if(!symbol || symbol!=dlsym(abi,"__cxa_throw"))return 4;
 puts("PASS RTLD_NOW binds full shared runtime and ABI alias alongside libstdc++");return 0;
}
