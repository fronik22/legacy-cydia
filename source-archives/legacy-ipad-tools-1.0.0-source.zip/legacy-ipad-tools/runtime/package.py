from pathlib import Path
import os,shutil,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));from package_deb import build_deb
B=ROOT/'build/runtime';stage=B/'stage';control=B/'control'
for p in [stage,control]:shutil.rmtree(p,ignore_errors=True);p.mkdir(parents=True)
lib=stage/'usr/lib';lib.mkdir(parents=True);shutil.copy2(B/'libc++.1.dylib',lib/'libc++.1.dylib')
for name in ['libc++.dylib','libc++abi.dylib']:(lib/name).symlink_to('libc++.1.dylib')
(control/'control').write_text('''Package: local.codex.libcxx-ios4
Name: Legacy C++ Runtime (iOS 4)
Version: 1.0.0
Architecture: iphoneos-arm
Description: Shared LLVM libc++ and libc++abi for armv7 iOS 4.3.x.
 Maintains legacy libstdc++ and installs no injection tweak.
Maintainer: Legacy iPad Tools
Section: Development
Depends: firmware (>= 4.3), firmware (<< 5.0)
''')
(control/'preinst').write_text('''#!/bin/sh
set -e
version=$(dpkg-query -W -f='${Version}' firmware)
if ! dpkg --compare-versions "$version" ge 4.3 || ! dpkg --compare-versions "$version" lt 5.0; then
 echo "This compatibility runtime is for iOS 4.3.x only; native libc++ on newer iOS must be preserved." >&2
 exit 1
fi
if [ "$1" = install ]; then
 for name in /usr/lib/libc++.1.dylib /usr/lib/libc++.dylib /usr/lib/libc++abi.dylib; do
  if [ -e "$name" ] || [ -L "$name" ]; then echo "Existing library: $name. Refusing replacement." >&2; exit 1; fi
 done
fi
''');(control/'preinst').chmod(0o755)
source=Path(os.environ.get('LEGACY_CPP_SOURCE',str(ROOT if (ROOT/'vendor').exists() else ROOT.parent/'unlocalsend-ios4')))
doc=stage/'usr/share/doc/local.codex.libcxx-ios4';doc.mkdir(parents=True)
for src,name in [(source/'vendor/libcxx-3.5-runtime/LICENSE.TXT','libcxx-LICENSE.txt'),(source/'vendor/libcxxabi-3.5.2.src/LICENSE.TXT','libcxxabi-LICENSE.txt')]:shutil.copy2(src,doc/name)
(doc/'README').write_text('App-independent LLVM libc++ release_35 + libc++abi 3.5.2 compatibility runtime. iOS 4.3.x armv7 only. Uninstall: dpkg -r local.codex.libcxx-ios4. Other iOS APIs are not backported. Matching source and build instructions accompany the package.\n')
build_deb(stage,control,ROOT/'dist/libcxx-ios4_1.0.0_iphoneos-arm.deb')
