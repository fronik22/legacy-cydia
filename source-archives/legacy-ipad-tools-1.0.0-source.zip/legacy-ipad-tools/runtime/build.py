"""Build an installable armv7/iOS4 shared libc++/libc++abi compatibility runtime."""
from pathlib import Path
import concurrent.futures,os,subprocess,json
ROOT=Path(__file__).resolve().parents[1];SRC=Path(os.environ.get('LEGACY_CPP_SOURCE',str(ROOT if (ROOT/'vendor').exists() else ROOT.parent/'unlocalsend-ios4')));BUILD=ROOT/'build/runtime';BUILD.mkdir(parents=True,exist_ok=True)
SDK=Path(os.environ['IOS4_SDK']);STUB=Path(os.environ.get('IOS4_STUB',str(ROOT/'build/sdk')));LDID=os.environ['IOS4_LDID'];V=SRC/'vendor';CXX=V/'libcxx-3.5-runtime';ABI=V/'libcxxabi-3.5.2.src';HEADERS=V/'libcxx-3.5-headers/include'
flags=['-target','armv7-apple-ios4.3','-isysroot',str(SDK),'-nostdinc++','-std=c++11','-Os','-D_LIBCPP_BUILDING_LIBRARY','-D_LIBCXXABI_BUILDING_LIBRARY','-I'+str(HEADERS),'-I'+str(ABI/'include'),'-Wno-deprecated-builtins','-Wno-reserved-user-defined-literal','-Wno-deprecated-declarations']
def run(cmd,log):
 p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True);(BUILD/log).write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(log+'\n'+p.stderr[-5000:])
def compile(source):
 obj=BUILD/(source.parent.parent.name+'-'+source.stem+'.o')
 if not obj.exists() or obj.stat().st_mtime<max(source.stat().st_mtime,Path(__file__).stat().st_mtime):run(['xcrun','clang++',*flags,'-c',source,'-o',obj],obj.name+'.log')
 return obj
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:objects=list(pool.map(compile,list((CXX/'src').glob('*.cpp'))+list((ABI/'src').glob('*.cpp'))))
(BUILD/'objects.txt').write_text('\n'.join(map(str,objects)))
run(['xcrun','ld-classic','-dylib','-arch','armv7','-iphoneos_version_min','4.3','-current_version','1.0','-compatibility_version','1.0','-install_name','/usr/lib/libc++.1.dylib','-syslibroot',STUB,'-L'+str(STUB/'usr/lib'),'-o',BUILD/'libc++.1.dylib','-filelist',BUILD/'objects.txt','-lgcc_s.1','-lSystem'],'link.log')
run([LDID,'-Cadhoc','-Hsha1','-S',BUILD/'libc++.1.dylib'],'sign.log')
for name in ['libc++.dylib','libc++abi.dylib']:
 p=BUILD/name
 if p.is_symlink():p.unlink()
 p.symlink_to('libc++.1.dylib')
exports=subprocess.check_output(['xcrun','nm','-gjU',str(BUILD/'libc++.1.dylib')],text=True).splitlines();assert '___cxa_throw' in exports and any('basic_string' in s for s in exports)
(BUILD/'exports.txt').write_text('\n'.join(exports)+'\n');print('Shared runtime built; exported symbols:',len(exports),flush=True)
