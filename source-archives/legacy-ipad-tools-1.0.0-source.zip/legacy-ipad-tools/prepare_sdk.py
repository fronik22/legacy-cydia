"""Generate legacy ARM import stubs from an externally supplied Apple SDK."""
from pathlib import Path
import os,re,json
ROOT=Path(__file__).resolve().parent
SDK=Path(os.environ['IOS4_SDK'])
STUB=ROOT/'build/sdk'
STUB.mkdir(parents=True,exist_ok=True)

def symbols(text,key):
 return re.findall(r'\b'+key+r':\s*\[([^]]*)\]',text,re.S)

def prepare():
 for f in SDK.rglob('*.tbd'):
  dst=STUB/f.relative_to(SDK); dst.parent.mkdir(parents=True,exist_ok=True)
  text=f.read_text();text=re.sub(r'    re-exports:\s*\[[^]]*\]\n','',text,flags=re.S)
  dst.write_text(text)
 # Resolve libc symbols through libSystem on the target OS, not modern sublibraries.
 syms=set()
 for f in (SDK/'usr/lib/system').glob('*.tbd'):
  for group in symbols(f.read_text(),'symbols'):
   syms.update(x.strip() for x in group.split(',') if x.strip())
 syms.update(['_start','dyld_stub_binder','_bzero','_memchr','_memcmp','_memcpy','_memmove','_memset','_strchr','_strcmp','_strncmp'])
 text='---\narchs: [ armv7 ]\nplatform: ios\ninstall-name: /usr/lib/libSystem.B.dylib\ncompatibility-version: 1\nexports:\n  - archs: [ armv7 ]\n    symbols: [ '+', '.join(sorted(syms))+' ]\n...\n'
 (STUB/'usr/lib/libSystem.tbd').write_text(text)

 # ARM compiler helpers were exported by libgcc_s on iOS 4.
 gcc=json.loads((ROOT/'compat/gcc-symbols.json').read_text())
 f=STUB/'usr/lib/libSystem.tbd';text=f.read_text()
 for name in gcc:text=re.sub(re.escape(name)+r'\s*,\s*','',text)
 f.write_text(text)
 (STUB/'usr/lib/libgcc_s.1.tbd').write_text('---\narchs: [ armv7 ]\nplatform: ios\ninstall-name: /usr/lib/libgcc_s.1.dylib\nexports:\n  - archs: [ armv7 ]\n    symbols: [ '+', '.join(gcc)+' ]\n...\n')
 # NSObject lived in CoreFoundation before iOS 6.
 f=STUB/'usr/lib/libobjc.tbd';text=f.read_text();text=re.sub(r'(?<!\w)_NSObject\s*,\s*','',text);text=re.sub(r'_NSObject[.]isa\s*,\s*','',text);text=text.replace('    symbols:', '    symbols:', 1)
 text=text.replace('...','  - archs: [ armv7 ]\n    symbols: [ __objc_empty_vtable, _objc_loadClassref ]\n...')
 f.write_text(text)
 for framework,classes,extra in [('CoreFoundation',['_NSObject'],[]),('UIKit',['_UIFont'],['_NSFontAttributeName','_NSForegroundColorAttributeName']),('AVFoundation',['_AVAudioSession'],[])]:
  f=STUB/f'System/Library/Frameworks/{framework}.framework/{framework}.tbd'
  text=f.read_text();addition='  - archs: [ armv7 ]\n    objc-classes: [ '+', '.join(classes)+' ]\n'
  if framework=='CoreFoundation':addition+='    objc-ivars: [ _NSObject.isa ]\n'
  if extra:addition+='    symbols: [ '+', '.join(extra)+' ]\n'
  f.write_text(text.replace('...',addition+'...'))

 # Network Objective-C classes lived in Foundation on iOS 4.
 network=['_NSHTTPCookie','_NSHTTPCookieStorage','_NSHTTPURLResponse','_NSURLProtocol','_NSURLConnection','_NSURLRequest','_NSMutableURLRequest','_NSURLResponse','_NSURLCache','_NSCachedURLResponse','_NSURLAuthenticationChallenge','_NSURLCredential','_NSURLProtectionSpace']
 f=STUB/'System/Library/Frameworks/CFNetwork.framework/CFNetwork.tbd';text=f.read_text()
 for name in network:text=re.sub(re.escape(name)+r'\s*,\s*','',text)
 f.write_text(text)
 f=STUB/'System/Library/Frameworks/Foundation.framework/Foundation.tbd'
 text=f.read_text().replace('...','  - archs: [ armv7 ]\n    objc-classes: [ '+', '.join(network)+' ]\n...');f.write_text(text)



 # Authentication constants also lived in Foundation on iOS 4.
 f=STUB/'System/Library/Frameworks/CFNetwork.framework/CFNetwork.tbd';text=f.read_text()
 names=sorted(set(re.findall(r'_NSURLAuthenticationMethod\w+|_NSURLErrorDomain',text)))
 for name in names:text=re.sub(re.escape(name)+r'\s*,\s*','',text)
 f.write_text(text)
 f=STUB/'System/Library/Frameworks/Foundation.framework/Foundation.tbd'
 text=f.read_text().replace('...','  - archs: [ armv7 ]\n    symbols: [ '+', '.join(names)+' ]\n...');f.write_text(text)

prepare()
print(STUB)
