from pathlib import Path
import shutil,sys,plistlib
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));from package_deb import build_deb
B=ROOT/'build/video-fix';stage=B/'stage';control=B/'control'
for p in [stage,control]:shutil.rmtree(p,ignore_errors=True);p.mkdir(parents=True)
lib=stage/'Library/MobileSubstrate/DynamicLibraries';lib.mkdir(parents=True);shutil.copy2(B/'Legacy60.dylib',lib/'Legacy60.dylib');(lib/'Legacy60.plist').write_bytes(plistlib.dumps({'Filter':{'Executables':['mediaserverd']}}))
(control/'control').write_text('''Package: local.codex.legacy60
Name: Legacy 1080p60 Timing Fix
Version: 1.0.0
Architecture: iphoneos-arm
Description: Corrects the iOS 4.3.3 real-time decode hint for iPad 2 1080p60 H.264.
 Preserves video frames, timestamps, audio, asynchronous and temporal decoding.
Maintainer: Legacy iPad Tools
Section: Tweaks
Depends: mobilesubstrate, firmware (= 4.3.3)
''')
(control/'preinst').write_text('''#!/bin/sh
set -e
version=$(dpkg-query -W -f='${Version}' firmware)
if [ "$version" != 4.3.3 ]; then echo "Legacy60 requires verified iOS 4.3.3." >&2; exit 1; fi
case "$(/usr/sbin/sysctl -n hw.machine)" in iPad2,*) ;; *) echo "Legacy60 requires iPad 2." >&2; exit 1;; esac
''');(control/'preinst').chmod(0o755)
(control/'postinst').write_text('#!/bin/sh\nset -e\n# Reload Substrate environment from the existing job; do not edit Apple files.\n/bin/launchctl unload /System/Library/LaunchDaemons/com.apple.mediaserverd.plist\n/bin/launchctl load /System/Library/LaunchDaemons/com.apple.mediaserverd.plist\n')
(control/'postinst').chmod(0o755)
(control/'postrm').write_text('#!/bin/sh\n/usr/bin/killall mediaserverd >/dev/null 2>&1 || true\nexit 0\n')
(control/'postrm').chmod(0o755)
doc=stage/'usr/share/doc/local.codex.legacy60';doc.mkdir(parents=True);(doc/'README').write_text('iPad 2 / iOS 4.3.3 (8J2) only. H.264 1920x1080, numeric sample timing 59.0-60.5 fps, output-enabled frames only. Clears only VTDecodeFrame_1xRealTimePlayback; does not discard/reencode frames or change timestamps. No policy file, daemon, network service or user settings. mediaserverd restarts on installation/removal, briefly interrupting playback. Uninstall: dpkg -r local.codex.legacy60. Restart device if a package installer suppresses maintainer scripts. Source, measured A/B comparisons and test limits accompany this release.\n')
shutil.copy2(ROOT/'LICENSE',doc/'COPYING')
build_deb(stage,control,ROOT/'dist/legacy60_1.0.0_iphoneos-arm.deb')
