from pathlib import Path
import os,subprocess
ROOT=Path(__file__).resolve().parents[1];B=ROOT/'build/video-fix';B.mkdir(parents=True,exist_ok=True);SDK=Path(os.environ['IOS4_SDK']);STUB=Path(os.environ['IOS4_STUB']);LDID=os.environ['IOS4_LDID']
commands=[['cc','-Wall','-Wextra','-Werror',ROOT/'video-fix/policy_test.c','-o',B/'policy-test'],[B/'policy-test'],['xcrun','clang','-target','armv7-apple-ios4.3','-isysroot',SDK,'-Os','-Wall','-Wextra','-Wno-unused-parameter','-c',ROOT/'video-fix/Legacy60.c','-o',B/'Legacy60.o'],['xcrun','ld-classic','-dylib','-arch','armv7','-iphoneos_version_min','4.3','-install_name','/Library/MobileSubstrate/DynamicLibraries/Legacy60.dylib','-syslibroot',STUB,'-L'+str(STUB/'usr/lib'),'-o',B/'Legacy60.dylib',B/'Legacy60.o','-framework','CoreMedia','-lSystem','-lgcc_s.1'],[LDID,'-Cadhoc','-Hsha1','-S',B/'Legacy60.dylib']]
for i,cmd in enumerate(commands):
 p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True);(B/f'build-{i}.log').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(p.stderr[-4000:])
 if p.stdout:print(p.stdout,end='')
print('Built guarded iPad2/iOS4.3.3 1080p60 timing tweak')
