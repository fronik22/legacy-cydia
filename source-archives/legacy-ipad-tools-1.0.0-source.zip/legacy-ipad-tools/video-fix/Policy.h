#ifndef LEGACY_60_POLICY_H
#define LEGACY_60_POLICY_H
#include <stdint.h>
static unsigned Legacy60Flags(unsigned flags,unsigned codec,int width,int height,int64_t duration,int32_t scale,int numeric){
    if(!(flags&4) || (flags&2) || codec!=0x61766331 || width!=1920 || height!=1080 || !numeric || duration<=0 || scale<=0)return flags;
    double fps=(double)scale/(double)duration;
    return fps>=59.0 && fps<=60.5?flags&~4u:flags;
}
#endif
