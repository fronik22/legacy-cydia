#include <CoreMedia/CoreMedia.h>
#include <VideoToolbox/VideoToolbox.h>
#include <sys/sysctl.h>
#include <syslog.h>
#include <dlfcn.h>
#include <string.h>
#include <libgen.h>
#include <mach-o/dyld.h>
#include "Policy.h"
static OSStatus (*Original)(VTDecompressionSessionRef,CMSampleBufferRef,VTDecodeFrameFlags,void *,VTDecodeInfoFlags *);
static volatile int reported;
static OSStatus Decode(VTDecompressionSessionRef session,CMSampleBufferRef sample,VTDecodeFrameFlags flags,void *context,VTDecodeInfoFlags *info){
    VTDecodeFrameFlags applied=flags;
    if(sample && (flags&kVTDecodeFrame_1xRealTimePlayback) && CMSampleBufferGetNumSamples(sample)==1){
        CMFormatDescriptionRef format=CMSampleBufferGetFormatDescription(sample);
        if(format && CMFormatDescriptionGetMediaType(format)==kCMMediaType_Video){
            CMVideoDimensions size=CMVideoFormatDescriptionGetDimensions(format);CMTime duration=CMSampleBufferGetDuration(sample);
            // iOS 4's real-time hint causes late delivery for this 1080p60 path; keep async/temporal flags.
            applied=Legacy60Flags(flags,CMFormatDescriptionGetMediaSubType(format),size.width,size.height,duration.value,duration.timescale,CMTIME_IS_NUMERIC(duration));
        }
    }
    if(applied!=flags && __sync_bool_compare_and_swap(&reported,0,1))syslog(LOG_NOTICE,"Legacy60: 1080p60 decode flags %u -> %u",(unsigned)flags,(unsigned)applied);
    return Original(session,sample,applied,context,info);
}
__attribute__((constructor)) static void Start(void){
    char build[64]={0},machine[64]={0},path[1024];size_t n=sizeof(build);uint32_t length=sizeof(path);
    if(sysctlbyname("kern.osversion",build,&n,NULL,0) || strcmp(build,"8J2"))return;
    n=sizeof(machine);if(sysctlbyname("hw.machine",machine,&n,NULL,0) || strncmp(machine,"iPad2,",6))return;
    if(_NSGetExecutablePath(path,&length) || strcmp(basename(path),"mediaserverd"))return;
    void *vt=dlopen("/System/Library/PrivateFrameworks/VideoToolbox.framework/VideoToolbox",RTLD_NOW|RTLD_LOCAL);
    void *substrate=dlopen("/Library/Frameworks/CydiaSubstrate.framework/CydiaSubstrate",RTLD_NOW|RTLD_LOCAL);
    void (*hook)(void *,void *,void **)=substrate?dlsym(substrate,"MSHookFunction"):NULL;void *target=vt?dlsym(vt,"VTDecompressionSessionDecodeFrame"):NULL;
    if(!hook || !target){syslog(LOG_ERR,"Legacy60: required decoder hook unavailable; unchanged");return;}
    Dl_info self;if(!dladdr((void *)&Start,&self) || !dlopen(self.dli_fname,RTLD_NOW|RTLD_LOCAL|RTLD_NODELETE))return;
    hook(target,(void *)&Decode,(void **)&Original);syslog(LOG_NOTICE,"Legacy60: enabled on %s %s",machine,build);
}
