#include "Policy.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 assert(Legacy60Flags(13,0x61766331,1920,1080,1,60,1)==9);
 assert(Legacy60Flags(13,0x61766331,1920,1080,1001,60000,1)==9);
 assert(Legacy60Flags(13,0x61766331,1920,1080,1,30,1)==13);
 assert(Legacy60Flags(13,0x61766331,1920,1080,1,120,1)==13);
 assert(Legacy60Flags(13,0x61766331,1280,720,1,60,1)==13);
 assert(Legacy60Flags(13,0x68766331,1920,1080,1,60,1)==13);
 assert(Legacy60Flags(15,0x61766331,1920,1080,1,60,1)==15);
 assert(Legacy60Flags(9,0x61766331,1920,1080,1,60,1)==9);
 assert(Legacy60Flags(13,0x61766331,1920,1080,0,60,1)==13);
 assert(Legacy60Flags(13,0x61766331,1920,1080,1,0,1)==13);
 assert(Legacy60Flags(13,0x61766331,1920,1080,-1,60,1)==13);
 assert(Legacy60Flags(13,0x61766331,1920,1080,1,60,0)==13);
 puts("PASS: 60/59.94 change only bit 4; 30/120fps, other formats/sizes, invalid timing and suppressed output unchanged");
}
