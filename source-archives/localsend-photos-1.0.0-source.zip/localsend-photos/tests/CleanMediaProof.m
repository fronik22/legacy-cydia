#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <dlfcn.h>
@interface NSObject (CleanMediaAPI)
- (void)choosePhoto;
- (void)clearSelection;
- (void)openGroup:(id)group;
- (void)tapAsset:(id)button;
- (void)finishSelection;
- (void)addPeer:(id)peer;
- (void)sendSelected;
@end
@interface CodexCleanMediaProof:NSObject {id _app;NSString *_folder;NSDictionary *_request;NSMutableDictionary *_result;unsigned _phase,_ticks,_waiting;}
- (void)start;
- (void)tick:(NSTimer *)timer;
@end
@implementation CodexCleanMediaProof
- (void)start {
 _app=[[UIApplication sharedApplication].delegate retain];_folder=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES)[0] retain];_request=[[NSDictionary dictionaryWithContentsOfFile:[_folder stringByAppendingPathComponent:@".codex-clean-media-request.plist"]] retain];_result=[NSMutableDictionary new];
 [_app clearSelection];[[UIDevice currentDevice] setValue:@3 forKey:@"orientation"];[_app choosePhoto];[NSTimer scheduledTimerWithTimeInterval:.25 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
}
- (void)tick:(NSTimer *)timer {
 NSAutoreleasePool *pool=[NSAutoreleasePool new];BOOL done=NO;
 @try {
 if(++_ticks>240)[NSException raise:@"Timeout" format:@"Clean media phase%u",_phase];
 UIWindow *window=[_app valueForKey:@"window"];UINavigationController *nav=(id)window.rootViewController.modalViewController;id picker=nav.topViewController;
 if(_phase==0){NSArray *groups=[picker valueForKey:@"groups"];if(groups.count){_result[@"groupCount"]=@(groups.count);[picker openGroup:groups[0]];_phase=1;}}
 else if(_phase==1){NSArray *assets=[picker valueForKey:@"assets"];if(assets.count){unsigned selected=0;for(NSUInteger index=0;index<assets.count;index++){ALAsset *asset=assets[index];long long size=asset.defaultRepresentation.size;if((size==2708 && [[asset valueForProperty:ALAssetPropertyType] isEqual:ALAssetTypeVideo]) || (size==11254 && [[asset valueForProperty:ALAssetPropertyType] isEqual:ALAssetTypePhoto])){UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];button.tag=index;[picker tapAsset:button];selected++;}}if(selected!=2)[NSException raise:@"Fixtures" format:@"Expected existing synthetic video/photo"];_result[@"assetCount"]=@(assets.count);_result[@"landscapeMediaWidth"]=@([[picker view] bounds].size.width);[[UIDevice currentDevice] setValue:@1 forKey:@"orientation"];_phase=2;_waiting=0;}}
 else if(_phase==2 && ++_waiting>=4){_result[@"portraitMediaWidth"]=@([[picker view] bounds].size.width);_result[@"selectedCount"]=@([[picker valueForKey:@"selectedURLs"] count]);[[UIDevice currentDevice] setValue:@3 forKey:@"orientation"];[picker finishSelection];_phase=3;}
 else if(_phase==3 && !nav){NSArray *files=[_app valueForKey:@"selectedFiles"];if(files.count!=2)[NSException raise:@"Export" format:@"Expected2 files"];_result[@"selectedFiles"]=files;NSDictionary *peer=_request[@"peer"];[_app addPeer:peer];[[_app valueForKey:@"hostField"] setText:peer[@"ip"]];[_app sendSelected];_phase=4;_waiting=0;}
 else if(_phase==4 && ++_waiting>=4 && ![[_app valueForKey:@"sending"] boolValue]){_result[@"receiverReady"]=[[_app valueForKey:@"receiver"] valueForKey:@"ready"];_result[@"status"]=[[_app valueForKey:@"statusLabel"] text]?:@"";_result[@"contentWidth"]=@([[_app valueForKey:@"content"] frame].size.width);_result[@"info"]=[[_app valueForKey:@"receiver"] performSelector:@selector(deviceInfo)];done=YES;}
 }@catch(NSException *error){_result[@"error"]=error.description;done=YES;}
 if(done){[timer invalidate];[_result writeToFile:[_folder stringByAppendingPathComponent:@".codex-clean-media-result.plist"] atomically:YES];}
 [pool drain];
}
@end
__attribute__((constructor)) static void Proof(void){Dl_info info;if(!dladdr((void *)&Proof,&info)||!dlopen(info.dli_fname,RTLD_NOW|RTLD_LOCAL|RTLD_NODELETE))return;dispatch_async(dispatch_get_main_queue(),^{[[CodexCleanMediaProof new] start];});}
