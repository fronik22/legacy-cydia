from pathlib import Path
import shutil,plistlib
from package_deb import build_deb
R=Path(__file__).resolve().parent;B=R/'build';stage=B/'stage';control=B/'control'
for p in [stage,control]:shutil.rmtree(p,ignore_errors=True);p.mkdir(parents=True)
lib=stage/'Library/MobileSubstrate/DynamicLibraries';lib.mkdir(parents=True);shutil.copy2(B/'LocalSendPhotos.dylib',lib/'LocalSendPhotos.dylib');(lib/'LocalSendPhotos.plist').write_bytes(plistlib.dumps({'Filter':{'Bundles':['com.unlocalsend.ios6']}}))
(control/'control').write_text('''Package: local.codex.localsend-photos
Name: LocalSend Photos Without Location
Version: 1.0.0
Architecture: iphoneos-arm
Description: Allows native AssetsLibrary access in LocalSend on iOS 4.3.3 without enabling Location Services.
 Scoped to com.unlocalsend.ios6 on build 8J2. Grants the app read access to Photos, including location metadata.
Maintainer: Legacy iPad Tools
Section: Tweaks
Depends: mobilesubstrate, firmware (= 4.3.3)
''')
(control/'preinst').write_text('''#!/bin/sh
set -e
if [ "$(/usr/sbin/sysctl -n kern.osversion)" != 8J2 ]; then echo "Verified iOS 4.3.3 (8J2) required." >&2; exit 1; fi
''');(control/'preinst').chmod(0o755)
for name in ['postrm']:
 (control/name).write_text('#!/bin/sh\n/usr/bin/killall LocalSend6 >/dev/null 2>&1 || true\nexit 0\n');(control/name).chmod(0o755)
(control/'postinst').write_text('#!/bin/sh\nset -e\n/usr/bin/killall LocalSend6 >/dev/null 2>&1 || true\n# Refresh the existing Substrate job environment without editing Apple files.\njob=/System/Library/LaunchDaemons/com.apple.SpringBoard.plist\n/bin/launchctl unload "$job"\n/bin/launchctl load "$job"\n');(control/'postinst').chmod(0o755)
doc=stage/'usr/share/doc/local.codex.localsend-photos';doc.mkdir(parents=True)
for name in ['README.md','LICENSE']:shutil.copy2(R/name,doc/name)
build_deb(stage,control,R/'dist/localsend-photos_1.0.0_iphoneos-arm.deb')
