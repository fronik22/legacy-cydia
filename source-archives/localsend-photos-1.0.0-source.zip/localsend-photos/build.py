from pathlib import Path
import os,subprocess
R=Path(__file__).resolve().parent;B=R/'build';B.mkdir(exist_ok=True)
sdk=Path(os.environ['IOS4_SDK']);stub=Path(os.environ['IOS4_STUB']);ldid=os.environ['IOS4_LDID']
commands=[['cc','-Wall','-Wextra','-Werror',R/'policy_test.c','-o',B/'policy-test'],[B/'policy-test'],['xcrun','clang','-target','armv7-apple-ios4.3','-isysroot',sdk,'-Os','-fno-objc-arc','-fblocks','-Wall','-Wextra','-Wno-unused-parameter','-c',R/'PhotosWithoutLocation.m','-o',B/'PhotosWithoutLocation.o'],['xcrun','ld-classic','-dylib','-arch','armv7','-iphoneos_version_min','4.3','-install_name','/Library/MobileSubstrate/DynamicLibraries/LocalSendPhotos.dylib','-syslibroot',stub,'-L'+str(stub/'usr/lib'),'-o',B/'LocalSendPhotos.dylib',B/'PhotosWithoutLocation.o','-framework','Foundation','-framework','CoreFoundation','-framework','AssetsLibrary','-lobjc','-lSystem','-lgcc_s.1'],[ldid,'-Cadhoc','-Hsha1','-S',B/'LocalSendPhotos.dylib']]
for index,args in enumerate(commands):
 p=subprocess.run(list(map(str,args)),capture_output=True,text=True);(B/f'build-{index}.log').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(p.stderr)
print('Policy checks passed; built LocalSendPhotos.dylib')
