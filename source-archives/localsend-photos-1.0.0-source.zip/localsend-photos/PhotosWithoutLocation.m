#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <sys/sysctl.h>
#include <syslog.h>
#include "Policy.h"
// iOS 4 uses 0=allowed, 1=user denied, 2=globally denied; this is not a BOOL.
static void AllowMedia(id self,SEL command,void (^reply)(id,int)){
    if(reply)reply(self,0);
}
__attribute__((constructor)) static void Start(void){
    NSAutoreleasePool *pool=[NSAutoreleasePool new];
    char build[64]={0};size_t size=sizeof(build);
    if(!sysctlbyname("kern.osversion",build,&size,NULL,0) && LegacyPhotosAllowed(build,[[[NSBundle mainBundle] bundleIdentifier] UTF8String])){
        Method method=class_getInstanceMethod(NSClassFromString(@"PersistentURLTranslatorAccess"),NSSelectorFromString(@"checkDataAccess:"));
        if(method && method_getNumberOfArguments(method)==3 && !strcmp(method_getTypeEncoding(method),"v12@0:4@?8")){
            method_setImplementation(method,(IMP)AllowMedia);
            syslog(LOG_NOTICE,"LocalSend Photos: native media access enabled without Location Services");
        }else syslog(LOG_ERR,"LocalSend Photos: unsupported permission method; unchanged");
    }
    [pool drain];
}
