#include <assert.h>
#include "Policy.h"
int main(void){
 assert(LegacyPhotosAllowed("8J2","com.unlocalsend.ios6"));
 assert(!LegacyPhotosAllowed("10B329","com.unlocalsend.ios6"));
 assert(!LegacyPhotosAllowed("8J2","com.apple.mobileslideshow"));
 assert(!LegacyPhotosAllowed("8J2","other.app"));
 assert(!LegacyPhotosAllowed(NULL,"com.unlocalsend.ios6"));
 assert(!LegacyPhotosAllowed("8J2",NULL));
 return 0;
}
