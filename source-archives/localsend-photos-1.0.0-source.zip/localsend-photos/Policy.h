#include <string.h>
static int LegacyPhotosAllowed(const char *build,const char *bundle){
    return build && bundle && !strcmp(build,"8J2") && !strcmp(bundle,"com.unlocalsend.ios6");
}
