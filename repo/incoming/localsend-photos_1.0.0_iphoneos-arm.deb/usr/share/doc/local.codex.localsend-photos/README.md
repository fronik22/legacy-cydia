# LocalSend Photos Without Location 1.0.0

Reversible Cydia Substrate tweak for jailbroken iOS 4.3.3 (8J2), armv7. Loads only into `com.unlocalsend.ios6` (this LocalSend port). Its native Photos permission callback returns the native allowed status, 0. Normal AssetsLibrary enumeration and original-file descriptor delivery remain Apple's implementations. Location Services stays off; no location updates, global privacy change, sandbox-profile change, daemon, or network service is installed.

Installing explicitly gives this app access to the photo/video library, including embedded GPS metadata. It removes the old location-based Photos permission gate for this app. Other apps and OS builds are untouched. No Photos files are altered. LocalSend's multi-select picker is supplied separately in the matching IPA; the tweak alone does not add UI.

Install `dpkg -i localsend-photos_1.0.0_iphoneos-arm.deb`. Remove `dpkg -r local.codex.localsend-photos`. Installation reloads the existing SpringBoard launch job to activate Substrate, briefly returning to the lock screen; no Apple file is edited. Removal closes only LocalSend. Reopen normally. Pending unsent selection is in memory and is lost when the app closes; original files and saved app settings remain.

Build with external Apple iPhoneOS9.3 SDK, prepared legacy import stubs and SHA1-capable ldid (not distributed). Set `IOS4_SDK`, `IOS4_STUB`, `IOS4_LDID`, then run `python3 build.py` and `python3 package.py`. `build.py` runs target-boundary policy checks first. See TEST-RESULTS.md and WORK-LOG.md for actual device verification and limitations. Other iOS 4 releases and other apps require separate validation before broadening the guards.
